"""Apply the user's confirmed wording without changing the scheduling model.

Formatting is inherited from the established paragraph and character styles.
The original comments, equations, figures and headings are retained.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from difflib import SequenceMatcher
from copy import deepcopy
from collections import Counter
import hashlib
import json
import re
from lxml import etree

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'inputs/基准稿_20261010.docx'
if not SOURCE.exists():
    SOURCE = ROOT.parent / 'report_styles_comments_20261010/开题报告_样式与新增批注修订稿_20261010.docx'
OUTPUT = ROOT / '开题报告_批注确认修订稿_20261010.docx'
W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
M = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
NS = {'w': W, 'm': M}
q = lambda n: '{' + W + '}' + n

with ZipFile(SOURCE) as z:
    payload = {n: z.read(n) for n in z.namelist()}
original_payload = dict(payload)
doc = etree.fromstring(payload['word/document.xml'])
ps = doc.xpath('//w:body//w:p', namespaces=NS)
assert len(ps) == 347
plain = lambda p: ''.join(p.xpath('.//w:t/text()', namespaces=NS))
before = [plain(p) for p in ps]
edits = []


def rewrite(p, new, reason, original_index):
    old = plain(p)
    if old == new:
        return
    ts = p.xpath('.//w:t', namespaces=NS)
    assert ts and not p.xpath('.//m:oMath | .//w:pict | .//w:drawing', namespaces=NS)
    codes = SequenceMatcher(None, old, new, autojunk=False).get_opcodes()

    def position(n):
        if n == 0:
            return 0
        if n == len(old):
            return len(new)
        for tag, a, b, c, d in codes:
            if a <= n <= b:
                if tag == 'equal':
                    return c + n - a
                if a == b:
                    return d
                return c + (n - a) * (d - c) // (b - a)
        raise AssertionError(n)

    offset = 0
    for t in ts:
        count = len(t.text or '')
        t.text = new[position(offset):position(offset + count)]
        if t.text.startswith(' ') or t.text.endswith(' '):
            t.set('{http://www.w3.org/XML/1998/namespace}space', 'preserve')
        offset += count
    assert plain(p) == new

    # Preserve comment identities and attach rewritten text to the full paragraph.
    ends = {e.get(q('id')): e for e in p.findall(q('commentRangeEnd'))}
    for start in list(p.findall(q('commentRangeStart'))):
        cid = start.get(q('id'))
        if cid not in ends:
            continue
        end = ends[cid]
        p.remove(start)
        p.remove(end)
        p.insert(1 if p.find(q('pPr')) is not None else 0, start)
        refs = [x for x in p if x.tag == q('r') and x.xpath('./w:commentReference[@w:id=$cid]', namespaces=NS, cid=cid)]
        p.insert(p.index(refs[0]) if refs else len(p), end)
    edits.append({'original_paragraph_index': original_index, 'before': old, 'after': new, 'reason': reason})


chosen_4_a = (
    '部分飞机装配研究从各站人员配置和作业时间安排开展优化。Fang等在工序所属站位已知的条件下，'
    '将作业时间划分为若干阶段，允许人员在阶段结束后重新调整所属站位[12]。Zheng等联合优化'
    '各站人数与工序安排，并要求人员在一个装配周期内不跨站调动[13]。本课题关注给定人员条件下'
    '工序、站位与具体人员团队的联合选择，并进一步研究延迟开工后的计划调整。'
)
chosen_8_a = (
    '重调度时，保留基准排程中计划开工时刻早于重调度时刻的工序安排，其执行站位、人员团队及'
    '起止时刻均不改变；其余工序根据已知的延迟情况和新的可开工条件重新安排。'
)
chosen_9_a = (
    '重调度继承基准排程已经形成的人员站位安排。基准排程中已使用的人员继续留在原站位，'
    '在本站可用人员中重新选择允许调整工序的执行团队；原先尚未使用的人员在首次参与作业时'
    '确定所属站位。'
)

replacements = {
    22: (
        '本课题关注扰动导致的工序延迟开工，即尚未开工工序的最早可开工时刻推迟。'
        '这种延迟可能由物料未就绪等原因引起。研究重点是延迟发生后的排程调整及其在多架次'
        '生产中的传递。扰动发生前，其时刻、目标和程度不可见；发生后获知本次持续时间或'
        '新的最早可开工时刻。已开工工序连续执行至完成，不因扰动中断，采用非抢占规则。',
        '确认1：删除物料处理表述，仅在背景中保留一次原因举例。'
    ),
    38: (chosen_4_a, '确认4：采用方案A，说明文献的人员换站条件及本课题的联合决策范围。'),
    42: (before[42].replace('飞机移动装配已有针对物料交付不确定性的研究。',
                          '飞机移动装配已有针对开工时间变化的重调度研究。'),
         '确认1同步：介绍文献的开工时间调整问题，不引入独立的物料延迟问题。'),
    43: (before[43].replace('将供给延迟、人员缺勤和质量问题引起的新约束纳入约束规划',
                          '将人员缺勤和质量问题等引起的新约束纳入约束规划'),
         '确认1同步：保留与调度相关的文献实例，不展开供给延迟。'),
    44: (
        '对本课题，重调度时需保留基准排程中计划开工时刻早于重调度时刻的工序安排，'
        '并沿用已使用人员的站位安排；其余工序在更新最早可开工时刻后重新安排。'
        '计划稳定性按相对于固定基准排程的开工时刻、执行站位和团队成员变化评价。'
        '研究问题由此从无扰动联合安排，扩展为工序延迟开工后兼顾完工时间与计划改动的重调度。',
        '确认8、9同步：在综述首次涉及保留范围时给出计划开工时刻判定，不使用冻结。'
    ),
    60: (before[60].replace('并考察物料延迟[27]', '并考察延迟开工扰动[27]'),
         '确认1同步：文献按开工延迟的调度影响介绍。'),
    141: (before[141].replace(
        '扰动发生后，根据原模型的冻结边界确定可调整工序，继承冻结安排和当前阶段人员站位绑定，',
        '扰动发生后，根据基准排程的计划开工时刻确定需要保留的原安排，沿用已使用人员的站位安排，'),
        '确认8、9同步：研究内容二说明需要保留的原安排及人员站位来源。'),
    142: (before[142].replace('冻结和人员绑定检查保证已有执行约束得到保留。',
        '通过核对原安排的保留情况和人员站位约束，检查已有执行约束是否得到遵守。'),
        '确认8、9同步：用具体检查内容替代冻结和绑定检查。'),
    169: (chosen_8_a + chosen_9_a, '确认8、9：采用两项方案A，保留原模型判定和未使用人员的首次指派规则。'),
    171: (before[171].replace('36个固定物料延迟场景', '36个固定工序延迟开工场景'),
        '确认1同步：既有场景按其对工序可开工时刻的影响描述，场景数量与实验结果不变。'),
    209: (before[209].replace('验证和测试时冻结参数及统计', '验证和测试时固定模型参数及统计量'),
        '同步易读性：明确验证和测试时固定的是模型参数和统计量。'),
    212: (before[212].replace('按现有论文的物料释放变化开展计划修复',
                            '按现有论文中设置的工序延迟开工场景开展计划修复'),
        '确认1同步：实验方案统一描述工序延迟开工，不单列物料释放问题。'),
    244: ('原安排保留情况、人员站位约束、结构对照、修复耗时',
        '确认8、9同步：评价指标使用可直接核查的约束表述。'),
    260: (before[260].replace('在保留冻结安排和人员站位绑定的条件下',
        '在保留规定工序的原安排并保持已使用人员站位不变的条件下'),
        '确认8、9同步：创新点不使用冻结，说明需要遵守的安排和人员站位约束。'),
    294: (before[294].replace('其物料延迟实验', '其工序延迟开工实验'),
        '确认1同步：可行性分析中的已有实验称谓与全文统一。'),
}
for i, (new, reason) in replacements.items():
    assert new != before[i], (i, 'No matched source phrase')
    rewrite(ps[i], new, reason, i)

# Move the retained web-reference comment to the reference chapter heading.
# Its original range would otherwise disappear with the three deleted records.
removed = ps[306:309]
assert [re.match(r'^\[(\d+)\]', plain(p)).group(1) for p in removed] == ['1', '2', '3']
markers = []
for p in removed:
    for x in p:
        if x.tag in (q('commentRangeStart'), q('commentRangeEnd')):
            markers.append(deepcopy(x))
        elif x.tag == q('r') and x.xpath('./w:commentReference', namespaces=NS):
            assert not x.xpath('./w:t[text()]', namespaces=NS)
            markers.append(deepcopy(x))
assert {x.get(q('id')) for x in markers if x.tag != q('r')} == {'11'}
target = ps[305]
for x in markers:
    if x.tag == q('commentRangeStart'):
        target.insert(1, x)
    else:
        target.append(x)
deleted_references = [plain(p) for p in removed]
for p in removed:
    p.getparent().remove(p)

# Re-number each body/table citation and reference entry in one pass.
pattern = re.compile(r'\[(\d+(?:\s*[,，\-–]\s*\d+)*)\]')
deleted_inline_count = 0
renumbered_count = 0


def renumber(match):
    global deleted_inline_count, renumbered_count
    text = match.group(1)
    nums = [int(x) for x in re.findall(r'\d+', text)]
    if not nums or not all(1 <= n <= 41 for n in nums):
        return match.group(0)
    if all(n <= 3 for n in nums):
        deleted_inline_count += 1
        return ''
    if any(n <= 3 for n in nums):
        # No such mixed citation occurs in this source; avoid silently guessing.
        raise AssertionError(('mixed deleted/live citation', text))
    renumbered_count += 1
    return '[' + re.sub(r'\d+', lambda m: str(int(m.group(0)) - 3), text) + ']'


for i, p in enumerate(ps):
    if p in removed:
        continue
    old = plain(p)
    new = pattern.sub(renumber, old)
    if old != new:
        rewrite(p, new, '确认12：删除三条官方网页来源后统一正文、表格及文后编号。', i)
assert deleted_inline_count == 3

payload['word/document.xml'] = etree.tostring(doc, xml_declaration=True, encoding='UTF-8', standalone=True)
with ZipFile(OUTPUT, 'w', ZIP_DEFLATED) as z:
    for name, content in payload.items():
        z.writestr(name, content)

# Structural checks of this actual revision, including cross-references.
assert payload['word/styles.xml'] == original_payload['word/styles.xml']
assert payload['word/comments.xml'] == original_payload['word/comments.xml']
comments = etree.fromstring(payload['word/comments.xml'])
ids = sorted(comments.xpath('./w:comment/@w:id', namespaces=NS))
for kind in ['commentRangeStart', 'commentRangeEnd', 'commentReference']:
    assert sorted(doc.xpath('//w:' + kind + '/@w:id', namespaces=NS)) == ids
current_ps = doc.xpath('//w:body//w:p', namespaces=NS)
refs = [p for p in current_ps if p.xpath('./w:pPr/w:pStyle/@w:val', namespaces=NS) == ['APALReference']]
assert len(refs) == 38
assert [int(re.match(r'^\[(\d+)\]', plain(p)).group(1)) for p in refs] == list(range(1, 39))
headings = [plain(p) for p in current_ps if p.xpath('./w:pPr/w:pStyle/@w:val', namespaces=NS) in [['1'], ['2'], ['3']]]
original_headings = [before[i] for i, p in enumerate(ps) if p.xpath('./w:pPr/w:pStyle/@w:val', namespaces=NS) in [['1'], ['2'], ['3']]]
assert headings == original_headings and len(headings) == 50
body_text = '\n'.join(plain(p) for p in current_ps if p not in refs)
assert body_text.count('物料') == 1 and '物料未就绪' in body_text
assert '物料延迟' not in body_text and '物料释放' not in body_text
assert '冻结' not in body_text and '物料未就绪等情况均按' not in body_text
assert '计划开工时刻早于重调度时刻' in body_text
assert '原先尚未使用的人员在首次参与作业时确定所属站位' in body_text
assert len(doc.xpath('//m:oMath', namespaces=NS)) == 13
original_doc = etree.fromstring(original_payload['word/document.xml'])
assert [etree.tostring(x) for x in doc.xpath('//m:oMath', namespaces=NS)] == [etree.tostring(x) for x in original_doc.xpath('//m:oMath', namespaces=NS)]
assert all(payload[k] == v for k, v in original_payload.items() if k.startswith('word/media/'))
assert len(doc.xpath('//w:rPr/w:rFonts | //w:rPr/w:sz | //w:rPr/w:szCs', namespaces=NS)) == 0
assert len(doc.xpath('//w:pPr/w:ind | //w:pPr/w:spacing | //w:pPr/w:jc | //w:pPr/w:outlineLvl', namespaces=NS)) == 0

audit = {
    'source': str(SOURCE), 'source_library_file_id': 'libfile_f7adfceb32488191a3cff88b8c5a78ff',
    'source_version': 1, 'source_sha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    'output': str(OUTPUT), 'output_sha256': hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
    'confirmed_schemes': {'4': 'A', '8': 'A', '9': 'A'},
    'edits': edits, 'deleted_web_references': deleted_references,
    'deleted_inline_citations': deleted_inline_count, 'renumbered_bracket_groups': renumbered_count,
    'reference_number_mapping': {str(n): n - 3 for n in range(4, 42)},
    'reference_count': len(refs), 'heading_count': len(headings), 'comment_count': len(ids),
    'native_equations_preserved': 13, 'paragraphs': len(current_ps),
    'styles_unchanged': True, 'media_unchanged': True,
    'model_rule': 'Retain baseline planned starts earlier than the rescheduling time; not substituted with actual started/completed status.',
    'evidence_scope': 'Existing delay cases described by operation-start consequences; no new experiments or claims of coverage of all disturbance causes.',
    'comment_12_reanchored_to': '9 参考文献',
    'pending': [],
}
(ROOT / '确认修改与编号核查记录_20261010.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2))
print(json.dumps({k: audit[k] for k in ['output', 'reference_count', 'heading_count', 'comment_count', 'paragraphs', 'styles_unchanged', 'media_unchanged', 'pending']}, ensure_ascii=False))
