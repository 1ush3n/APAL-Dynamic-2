"""Apply the confirmed local revisions and a style-based format system.

Source package parts, figures, equation images and comment identities are retained.
Run with the Codex primary Python runtime.
"""
from __future__ import annotations
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from copy import deepcopy
from difflib import SequenceMatcher
import hashlib
import json
import re
from lxml import etree

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "inputs/批注来源_20261010.docx"
if not SOURCE.exists():
    SOURCE = ROOT.parent / "upload/开题报告_批注修订稿_20261010(1).docx"
OUTPUT = ROOT / "开题报告_样式与新增批注修订稿_20261010.docx"
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
NS = {"w": W, "v": "urn:schemas-microsoft-com:vml", "m": M}
XML_SPACE = "{http://www.w3.org/XML/1998/namespace}space"
q = lambda name: f"{{{W}}}{name}"

def el(name, **attrs):
    x = etree.Element(q(name))
    for key, val in attrs.items():
        x.set(q(key), str(val))
    return x

def child(parent, name, **attrs):
    x = el(name, **attrs)
    parent.append(x)
    return x

def plain(p):
    return "".join(p.xpath(".//w:t/text()", namespaces=NS))

with ZipFile(SOURCE) as src:
    payload = {n: src.read(n) for n in src.namelist()}
doc = etree.fromstring(payload["word/document.xml"])
styles = etree.fromstring(payload["word/styles.xml"])
ps = doc.xpath("//w:body//w:p", namespaces=NS)
assert len(ps) == 347
source_text = [plain(p) for p in ps]
edit_log = []
style_log = []
recovered_math = []
annotation_styles_cleared = 0
original_comments = payload["word/comments.xml"]
media_digest = {k: hashlib.sha256(v).hexdigest()
                for k, v in payload.items() if k.startswith("word/media/")}

# Build all formatting styles before formatting any document paragraph.
def paragraph_style(sid, name, *, size=24, cjk="宋体", align="both",
                    first_chars=0, first_twips=0, before=0, after=0,
                    line=400, line_rule="exact", bold=False, level=9,
                    keep_next=False, keep_lines=False, based="a",
                    left=0, right=0, hanging=None, ui=None):
    existing = styles.xpath("./w:style[@w:styleId=$sid]", namespaces=NS, sid=sid)
    if existing:
        s = existing[0]
        for c in list(s):
            s.remove(c)
    else:
        s = etree.SubElement(styles, q("style"))
    s.set(q("type"), "paragraph")
    s.set(q("styleId"), sid)
    if sid == "a":
        s.set(q("default"), "1")
    elif sid not in ("1", "2", "3", "Title"):
        s.set(q("customStyle"), "1")
    child(s, "name", val=name)
    if based and sid != based:
        child(s, "basedOn", val=based)
    child(s, "next", val="a")
    if ui is not None:
        child(s, "uiPriority", val=ui)
    child(s, "qFormat")
    pp = child(s, "pPr")
    if keep_next:
        child(pp, "keepNext")
    if keep_lines:
        child(pp, "keepLines")
    child(pp, "widowControl")
    child(pp, "suppressAutoHyphens")
    child(pp, "spacing", before=before, after=after, line=line, lineRule=line_rule)
    ind = dict(left=left, right=right)
    if hanging is None:
        ind.update(firstLine=first_twips, firstLineChars=first_chars)
    else:
        ind.update(hanging=hanging, hangingChars=200)
    child(pp, "ind", **ind)
    child(pp, "jc", val=align)
    child(pp, "outlineLvl", val=level)
    rp = child(s, "rPr")
    child(rp, "rFonts", ascii="Times New Roman", hAnsi="Times New Roman",
          eastAsia=cjk, cs="Times New Roman")
    child(rp, "b", val="1" if bold else "0")
    child(rp, "bCs", val="1" if bold else "0")
    child(rp, "color", val="000000")
    child(rp, "sz", val=size)
    child(rp, "szCs", val=size)
    style_log.append({"id": sid, "name": name, "size_pt": size / 2,
                      "cjk": cjk, "latin": "Times New Roman",
                      "outline": level, "first_line_chars": first_chars,
                      "line": line, "line_rule": line_rule, "align": align})
    return s

paragraph_style("a", "Normal", first_chars=200, first_twips=480, ui=0)
paragraph_style("1", "heading 1", size=32, cjk="黑体", align="center",
                before=480, after=360, line=240, line_rule="auto",
                bold=True, level=0, keep_next=True, keep_lines=True, ui=1)
paragraph_style("2", "heading 2", size=30, cjk="黑体", align="left",
                before=480, after=120, line=240, line_rule="auto",
                bold=True, level=1, keep_next=True, keep_lines=True, ui=2)
paragraph_style("3", "heading 3", size=28, cjk="黑体", align="left",
                before=240, after=120, line=240, line_rule="auto",
                bold=True, level=2, keep_next=True, keep_lines=True, ui=3)
paragraph_style("Title", "Title", size=36, cjk="黑体", align="center",
                left=1780, right=1780, after=280, line=600, bold=True,
                keep_next=True, keep_lines=True, ui=10)
paragraph_style("APALFormTitle", "模板表题", size=36, cjk="黑体", align="center",
                before=640, after=280, line=600, bold=True, keep_lines=True)
paragraph_style("APALInstructionsHead", "模板说明标题", bold=True,
                align="left", after=160, keep_next=True)
paragraph_style("APALInstructions", "模板说明正文", align="left", before=120)
paragraph_style("APALBodyMath", "含公式正文", first_chars=200, first_twips=480,
                line_rule="atLeast")
paragraph_style("APALEquationIntro", "公式说明", first_chars=200, first_twips=480,
                line_rule="atLeast", keep_next=True)
paragraph_style("APALTableText", "表格正文", size=21, align="left",
                line=340, line_rule="atLeast")
paragraph_style("APALTableCenter", "表格居中正文", size=21, align="center",
                line=340, line_rule="atLeast")
paragraph_style("APALTableHeader", "表格表头", size=21, cjk="黑体",
                align="center", line=340, line_rule="atLeast", bold=True, keep_lines=True)
paragraph_style("APALFigure", "插图", align="center", before=120, after=60,
                line=240, line_rule="auto", keep_next=True, keep_lines=True)
paragraph_style("APALEquation", "独立公式", align="center",
                before=120, after=120, line_rule="atLeast", keep_lines=True)
paragraph_style("APALFigureCaption", "图题", size=21, align="center",
                before=120, after=240, line=240, line_rule="auto", keep_lines=True)
paragraph_style("APALTableCaption", "表题", size=21, align="center",
                before=120, after=120, line=240, line_rule="auto",
                keep_next=True, keep_lines=True)
paragraph_style("APALReference", "参考文献条目", size=21, align="left",
                line=320, line_rule="atLeast", left=420, hanging=420, keep_lines=True)
paragraph_style("APALFooter", "页码", size=20, align="center",
                line=240, line_rule="auto")
paragraph_style("APALHeader", "页眉正文", size=20, align="center",
                line=240, line_rule="auto")
paragraph_style("APALBlank", "空白段落", align="left", line=240, line_rule="auto")

# Character styles preserve semantics without reintroducing font/size overrides.
def character_style(sid, name, **properties):
    old = styles.xpath("./w:style[@w:styleId=$sid]", namespaces=NS, sid=sid)
    s = old[0] if old else etree.SubElement(styles, q("style"))
    for c in list(s):
        s.remove(c)
    s.set(q("type"), "character")
    s.set(q("styleId"), sid)
    s.set(q("customStyle"), "1")
    child(s, "name", val=name)
    child(s, "basedOn", val="a0")
    rp = child(s, "rPr")
    for k, v in properties.items():
        child(rp, k, val=v)

character_style("APALEmphasis", "正文强调", b="1", bCs="1")
character_style("APALItalic", "正文斜体", i="1", iCs="1")
character_style("APALSuperscript", "上标文字", vertAlign="superscript")
character_style("APALSubscript", "下标文字", vertAlign="subscript")
character_style("APALWebAddress", "网页地址", spacing="-2")
character_style("APALMath", "数学公式文字")
math_style = styles.xpath("./w:style[@w:styleId='APALMath']", namespaces=NS)[0]
math_rp = math_style.find(q("rPr"))
child(math_rp, "rFonts", ascii="Cambria Math", hAnsi="Cambria Math",
      eastAsia="Cambria Math", cs="Cambria Math")
child(math_rp, "color", val="000000")
child(math_rp, "sz", val=24)
child(math_rp, "szCs", val=24)

# Default fonts are explicit as well; all application styles specify their fonts.
defaults = styles.find(q("docDefaults"))
if defaults is not None:
    rpd = defaults.find(q("rPrDefault"))
    if rpd is not None:
        rp = rpd.find(q("rPr"))
        if rp is None:
            rp = child(rpd, "rPr")
        for c in list(rp):
            if etree.QName(c).localname in {"rFonts", "sz", "szCs", "color"}:
                rp.remove(c)
        child(rp, "rFonts", ascii="Times New Roman", hAnsi="Times New Roman",
              eastAsia="宋体", cs="Times New Roman")
        child(rp, "color", val="000000")
        child(rp, "sz", val=24)
        child(rp, "szCs", val=24)

# Text edits retain the existing run structure and all comment markers.
def revise_text(index, new, reason):
    p = ps[index]
    old = plain(p)
    if old == new:
        return
    ts = p.xpath(".//w:t", namespaces=NS)
    assert ts and not p.xpath(".//w:pict | .//w:drawing | .//w:object", namespaces=NS)
    opcodes = SequenceMatcher(None, old, new, autojunk=False).get_opcodes()

    def translate(pos):
        if pos == 0:
            return 0
        if pos == len(old):
            return len(new)
        for tag, a, b, c, d in opcodes:
            if a <= pos <= b:
                if tag == "equal":
                    return c + pos - a
                if b == a:
                    return d
                return c + (pos - a) * (d - c) // (b - a)
        raise AssertionError(pos)

    cursor = 0
    for t in ts:
        n = len(t.text or "")
        a, b = translate(cursor), translate(cursor + n)
        t.text = new[a:b]
        if t.text.startswith(" ") or t.text.endswith(" "):
            t.set(XML_SPACE, "preserve")
        cursor += n
    assert plain(p) == new

    # For comments entirely in this rewritten paragraph, preserve the identity
    # and widen its range to the new paragraph instead of leaving an empty anchor.
    starts = p.findall(q("commentRangeStart"))
    ends = {e.get(q("id")): e for e in p.findall(q("commentRangeEnd"))}
    for start in starts:
        cid = start.get(q("id"))
        if cid not in ends:
            continue
        end = ends[cid]
        p.remove(start)
        p.remove(end)
        pos = 1 if p.find(q("pPr")) is not None else 0
        p.insert(pos, start)
        reference_runs = [
            c for c in p if c.tag == q("r")
            and c.xpath("./w:commentReference[@w:id=$cid]",
                        namespaces=NS, cid=cid)
        ]
        p.insert(p.index(reference_runs[0]) if reference_runs else len(p), end)
    edit_log.append({"paragraph": index, "before": old, "after": new, "reason": reason})

revise_text(
    22,
    "本课题关注扰动导致的工序延迟开工，即尚未开工工序的最早可开工时刻推迟。"
    "物料未就绪等情况均按其对工序开工条件的影响处理，重点研究延迟发生后的排程调整"
    "及其在多架次生产中的传递。扰动发生前，其时刻、目标和程度不可见；发生后获知"
    "本次持续时间或新的最早可开工时刻。已开工工序连续执行至完成，不因扰动中断，"
    "采用非抢占规则。",
    "批注1：面向整个课题统一说明延迟开工，取消前期与后续的划分。"
)
revise_text(
    27,
    "已有飞机装配线研究表明，部分未完成作业可随飞机转站后继续安排。"
    "例如，在Hawker Beechcraft公司的Hawker 800XP装配线上，飞机按预定时间转站，"
    "未在原定站位完成的作业可在转站后继续执行[9]。本课题考虑有限工序后移，"
    "要求后移安排满足工艺前序、单向流动和人员约束，且不迫使其他工序新增换站。",
    "批注2：以文献中的实际生产安排支持有限工序后移，避免口语化的介绍了。"
)
revise_text(
    36,
    "飞机装配中的工序分站与作业安排涉及装配线平衡和调度。装配线平衡研究工序向"
    "有序站位的分配，并在工艺前序等约束下优化站位数量、周期或负荷目标；调度确定"
    "工序的作业顺序、起止时刻及资源使用[5,15]。Boysen等的分类和Becker与Scholl"
    "的广义装配线平衡综述建立了基本问题体系[10,11]。Boysen、Schulze与Scholl"
    "进一步总结近十五年的进展，讨论多人站位、人员指派和实际生产扩展[5]。",
    "批注3：先说明平衡和调度的联系，再分别给出定义，保留原有权威综述。"
)
for i, old in enumerate(source_text):
    if "工作二" in old or "工作三" in old:
        new = plain(ps[i]).replace("工作二", "研究内容二").replace("工作三", "研究内容三")
        revise_text(i, new, "批注11：统一正文和进度表中的研究内容称谓。")

# Three existing web references retain their numbering and claims.
web_refs = {
    306: "[1] 中华人民共和国国民经济和社会发展第十五个五年规划纲要[EB/OL]. "
         "(2026-03-14)[2026-10-10]. "
         "https://www.ln.gov.cn/web/ywdt/rdgz/2026031407581924489/index.shtml.",
    307: "[2] 工业和信息化部等八部门. 工业和信息化部等八部门关于印发"
         "《“人工智能+制造”专项行动实施意见》的通知[EB/OL]. "
         "(2026-01-07)[2026-10-10]. "
         "https://www.miit.gov.cn/jgsj/kjs/wjfb/art/2026/art_5ea5b1663f264fcea69df0ab00d1f6f3.html.",
    308: "[3] 上海飞机制造有限公司. 贯彻1号文丨乘改革之势，聚攻坚之力，强发展之效[EB/OL]. "
         "(2025-04-17)[2026-10-10]. "
         "https://samc.comac.cc/xwzx/sfyxw/202504/17/t20250417_7404410.shtml.",
}
for i, text in web_refs.items():
    revise_text(i, text, "批注12：核对具体网页题名、页面发布日期及本次引用日期，保留出处。")

# Word's picture-based QUOTE fields retain the equation XML, but one display
# equation has corrupted XML and clipped lower limits. Restore the same 13
# mathematical expressions, cross-checked against the last native-formula copy.
# All user-edited prose continues to come from SOURCE, never from that copy.
native_source = ROOT / "确认公式_OMML_20261010.xml"
if native_source.exists():
    prior_doc = etree.parse(str(native_source)).getroot()
else:
    native_source = ROOT.parent / "report_revision_20261010_1020/deliverables/开题报告_批注修订稿_20261010.docx"
    with ZipFile(native_source) as nz:
        prior_doc = etree.fromstring(nz.read("word/document.xml"))
prior_math = prior_doc.xpath("//m:oMath", namespaces=NS)
assert len(prior_math) == 13
math_cursor = 0

def normalized_math_text(x):
    text = "".join(x.xpath(".//m:t/text()", namespaces=NS))
    return re.sub(r"\s+", "", text).replace("−", "-")

for pi, p in enumerate(ps):
    children = list(p)
    ranges = []
    ci = 0
    while ci < len(children):
        c = children[ci]
        fc = c.xpath("./w:fldChar/@w:fldCharType", namespaces=NS)
        end = ci
        if fc == ["begin"]:
            level = 1
            while end + 1 < len(children) and level:
                end += 1
                types = children[end].xpath("./w:fldChar/@w:fldCharType", namespaces=NS)
                level += types.count("begin") - types.count("end")
            assert level == 0
        group = children[ci:end + 1]
        shapes = [s for g in group for s in g.xpath(".//*[@equationxml]")]
        if shapes:
            values = {s.get("equationxml") for s in shapes}
            assert len(values) == 1
            assert not any(g.xpath(".//w:t[text()]", namespaces=NS) for g in group)
            if fc:
                instruction = "".join(t for g in group for t in g.xpath(".//w:instrText/text()", namespaces=NS))
                assert instruction.strip() == "QUOTE"
            raw = next(iter(values))
            if pi == 25:
                # This source encodes membership as mojibake and has invalid tags;
                # keep the confirmed formula max_{k in K_q} F_{k,q} from the prior.
                assert "鈭?/m:t>" in raw and math_cursor == 4
                verification = "Verified against prior native equation and the current paragraph definition."
            else:
                decoded = etree.fromstring(raw.encode("utf-8"))
                mm = decoded.xpath("//m:oMath", namespaces=NS)
                assert len(mm) == 1
                assert normalized_math_text(mm[0]) == normalized_math_text(prior_math[math_cursor])
                verification = "Embedded equation XML agrees with prior native equation."
            native = deepcopy(prior_math[math_cursor])
            for rp in native.xpath(".//w:rPr", namespaces=NS):
                for t in list(rp):
                    rp.remove(t)
                child(rp, "rStyle", val="APALMath")
            if not plain(p).strip():
                wrapper = etree.Element(f"{{{M}}}oMathPara")
                props = etree.SubElement(wrapper, f"{{{M}}}oMathParaPr")
                jc = etree.SubElement(props, f"{{{M}}}jc")
                jc.set(f"{{{M}}}val", "center")
                wrapper.append(native)
                replacement = wrapper
            else:
                replacement = native
            ranges.append((group, replacement))
            recovered_math.append({"paragraph": pi, "equation": normalized_math_text(native),
                                   "verification": verification})
            math_cursor += 1
        ci = end + 1
    for group, replacement in ranges:
        location = p.index(group[0])
        for c in group:
            p.remove(c)
        p.insert(location, replacement)
assert math_cursor == 13

CLEAR_P = {
    "pStyle", "keepNext", "keepLines", "pageBreakBefore", "widowControl",
    "suppressAutoHyphens", "spacing", "ind", "contextualSpacing", "jc",
    "textAlignment", "outlineLvl", "numPr", "pBdr", "shd", "rPr", "tabs",
}
# Run formatting is inherited from paragraph/character styles, never font-by-font.
CLEAR_R = {
    "rFonts", "b", "bCs", "i", "iCs", "color", "sz", "szCs", "kern",
    "spacing", "w", "position", "u", "highlight", "shd", "vertAlign",
}

def apply_style(p, sid):
    global annotation_styles_cleared
    pp = p.find(q("pPr"))
    if pp is None:
        pp = el("pPr")
        p.insert(0, pp)
    for c in list(pp):
        if etree.QName(c).localname in CLEAR_P:
            pp.remove(c)
    pp.insert(0, el("pStyle", val=sid))
    for rp in p.xpath(".//w:r/w:rPr", namespaces=NS):
        old_style = rp.find(q("rStyle"))
        if (old_style is not None and old_style.get(q("val")) == "af"
                and not rp.getparent().xpath("./w:commentReference", namespaces=NS)):
            rp.remove(old_style)
            old_style = None
            annotation_styles_cleared += 1
        emphasis = rp.find(q("b"))
        italic = rp.find(q("i"))
        vertical = rp.find(q("vertAlign"))
        char_sid = None
        if vertical is not None:
            char_sid = {"superscript": "APALSuperscript",
                        "subscript": "APALSubscript"}.get(vertical.get(q("val")))
        elif italic is not None and italic.get(q("val"), "1") not in ("0", "false"):
            char_sid = "APALItalic"
        elif (emphasis is not None and emphasis.get(q("val"), "1") not in ("0", "false")
              and sid not in ("1", "2", "3", "Title", "APALFormTitle",
                              "APALInstructionsHead", "APALTableHeader")):
            char_sid = "APALEmphasis"
        for c in list(rp):
            if etree.QName(c).localname in CLEAR_R:
                rp.remove(c)
        if char_sid and old_style is None:
            rp.insert(0, el("rStyle", val=char_sid))
        if not len(rp):
            rp.getparent().remove(rp)

paragraph_roles = []
for i, p in enumerate(ps):
    text = plain(p).strip()
    in_table = bool(p.xpath("ancestor::w:tbl", namespaces=NS))
    if in_table:
        continue
    if i == 0:
        sid = "APALInstructionsHead"
    elif i == 5:
        sid = "APALFormTitle"
    elif i == 7:
        sid = "Title"
    elif not text and not p.xpath(".//w:pict | .//m:oMath", namespaces=NS):
        sid = "APALBlank"
    elif re.match(r"^\d+\.\d+\.\d+\s", text):
        sid = "3"
    elif re.match(r"^\d+\.\d+\s", text):
        sid = "2"
    elif re.match(r"^[1-9]\s", text):
        sid = "1"
    elif re.match(r"^\[\d+\]\s", text):
        sid = "APALReference"
    elif re.match(r"^图\s*\d+\s", text):
        sid = "APALFigureCaption"
    elif re.match(r"^表\s*\d+\s", text):
        sid = "APALTableCaption"
    elif p.xpath(".//w:pict | .//m:oMath", namespaces=NS):
        if text:
            sid = "APALEquationIntro" if i in (24, 201, 203) else "APALBodyMath"
        else:
            shapes = p.xpath(".//v:shape", namespaces=NS)
            sizes = [re.search(r"height:([0-9.]+)pt", x.get("style", "")) for x in shapes]
            maximum = max((float(m.group(1)) for m in sizes if m), default=0)
            sid = "APALFigure" if maximum > 45 else "APALEquation"
    else:
        sid = "a"
    apply_style(p, sid)
    paragraph_roles.append({"paragraph": i, "style": sid, "text": text[:100]})

for ti, table in enumerate(doc.xpath("//w:tbl", namespaces=NS)):
    rows = table.findall(q("tr"))
    for ri, row in enumerate(rows):
        trp = row.find(q("trPr"))
        if trp is None:
            trp = el("trPr")
            row.insert(0, trp)
        for height in trp.findall(q("trHeight")):
            if height.get(q("hRule")) == "exact":
                height.set(q("hRule"), "atLeast")
        if ti > 0 and ri == 0 and trp.find(q("tblHeader")) is None:
            child(trp, "tblHeader")
        if ti > 0 and trp.find(q("cantSplit")) is None:
            child(trp, "cantSplit")
        for ci, cell in enumerate(row.findall(q("tc"))):
            tcp = cell.find(q("tcPr"))
            if tcp is None:
                tcp = el("tcPr")
                cell.insert(0, tcp)
            va = tcp.find(q("vAlign"))
            if va is None:
                va = child(tcp, "vAlign", val="center")
            else:
                va.set(q("val"), "center")
            for p in cell.xpath(".//w:p", namespaces=NS):
                if ti == 0:
                    sid = "APALInstructions"
                elif ri == 0:
                    sid = "APALTableHeader"
                elif ci == 0:
                    sid = "APALTableCenter"
                else:
                    sid = "APALTableText"
                apply_style(p, sid)
                paragraph_roles.append({"paragraph": ps.index(p), "style": sid,
                                        "table": ti, "text": plain(p)[:100]})

# Style existing page numbers and headers without changing fields or layout rules.
changed_parts = ["word/document.xml", "word/styles.xml"]
for name in list(payload):
    if re.match(r"word/(footer|header)\d+\.xml$", name):
        x = etree.fromstring(payload[name])
        for p in x.xpath("//w:p", namespaces=NS):
            apply_style(p, "APALFooter" if "footer" in name else "APALHeader")
        payload[name] = etree.tostring(x, xml_declaration=True, encoding="UTF-8",
                                      standalone=True)
        changed_parts.append(name)

# A small style-based tracking adjustment keeps the final punctuation of long
# official URLs with the address, rather than leaving a full stop on its own line.
web_style_count = 0
for index in web_refs:
    p = ps[index]
    for run in list(p.findall(q("r"))):
        text_nodes = run.findall(q("t"))
        if len(text_nodes) != 1:
            continue
        value = text_nodes[0].text or ""
        match = re.search(r"https?://\S+", value)
        if not match:
            continue
        assert all(c.tag in (q("rPr"), q("t")) for c in run)
        insertion = p.index(run)
        fragments = [value[:match.start()], match.group(), value[match.end():]]
        for fi, fragment in enumerate(fragments):
            if not fragment:
                continue
            nr = el("r")
            if fi == 1:
                child(child(nr, "rPr"), "rStyle", val="APALWebAddress")
                web_style_count += 1
            tt = child(nr, "t")
            tt.text = fragment
            tt.set(XML_SPACE, "preserve")
            p.insert(insertion, nr)
            insertion += 1
        p.remove(run)
assert web_style_count == 3

payload["word/document.xml"] = etree.tostring(
    doc, xml_declaration=True, encoding="UTF-8", standalone=True)
payload["word/styles.xml"] = etree.tostring(
    styles, xml_declaration=True, encoding="UTF-8", standalone=True)
with ZipFile(OUTPUT, "w", ZIP_DEFLATED) as z:
    for name, blob in payload.items():
        z.writestr(name, blob)

# Targeted invariants: content, heading navigation, comments and source media.
assert payload["word/comments.xml"] == original_comments
assert {k: hashlib.sha256(v).hexdigest() for k, v in payload.items()
        if k.startswith("word/media/")} == media_digest
for i in (38, 169):
    assert plain(ps[i]) == source_text[i], "Pending candidate paragraph was changed"
headings = [r for r in paragraph_roles if r["style"] in ("1", "2", "3")]
refs = [r for r in paragraph_roles if r["style"] == "APALReference"]
assert len(refs) == 41
for role in headings:
    ss = styles.xpath("./w:style[@w:styleId=$sid]", namespaces=NS,
                      sid=role["style"])[0]
    assert ss.find("./" + q("pPr") + "/" + q("outlineLvl")).get(q("val")) == str(int(role["style"]) - 1)
assert len(doc.xpath("//w:commentRangeStart", namespaces=NS)) == 12
assert len(doc.xpath("//w:commentRangeEnd", namespaces=NS)) == 12
assert len(doc.xpath("//w:commentReference", namespaces=NS)) == 12

audit = {
    "source": str(SOURCE),
    "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "output": str(OUTPUT),
    "output_sha256": hashlib.sha256(OUTPUT.read_bytes()).hexdigest(),
    "edits": edit_log,
    "styles": style_log,
    "headings": headings,
    "heading_counts": {k: sum(x["style"] == k for x in headings) for k in ("1", "2", "3")},
    "paragraph_roles": paragraph_roles,
    "table_count": len(doc.xpath("//w:tbl", namespaces=NS)),
    "reference_count": len(refs),
    "comments_preserved": 12,
    "media_sha256": media_digest,
    "changed_package_parts": changed_parts,
    "equation_representation": "13 matching source expressions restored to native Word equations; source figure media retained unchanged.",
    "recovered_math": recovered_math,
    "invalid_annotation_character_styles_removed": annotation_styles_cleared,
    "native_math_comparison_source": str(native_source),
    "web_address_character_style_runs": web_style_count,
    "pending_content_paragraphs": [38, 169],
}
(ROOT / "修改与样式检查记录_20261010.json").write_text(
    json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({
    "output": str(OUTPUT), "edits": len(edit_log),
    "heading_counts": audit["heading_counts"],
    "tables": audit["table_count"], "references": len(refs),
    "comments": 12, "media_unchanged": True,
}, ensure_ascii=False))

