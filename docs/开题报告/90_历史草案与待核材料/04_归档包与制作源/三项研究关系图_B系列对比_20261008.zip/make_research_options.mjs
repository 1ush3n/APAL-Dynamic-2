import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const sharp=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/sharp');
const root='/workspace/scratch/0dffb7d03718/opening_ppt_chapters_20261008';
const out=path.join(root,'deliverables');
const allText=[]; let xml=[], variant='';
const esc=t=>String(t).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
function start(v){variant=v;xml=[`<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="1080" viewBox="0 0 1600 1080">`,
 '<title>三项研究内容及其递进关系</title>',
 '<desc>问题、研究内容和目标对应。同构图无扰动联合调度，扩展至异构图联合调度与稳定性重调度，再扩展至语义增强的多架次协同动态调度。内部图形为研究内容示意，不表示已取得实验结果。</desc>',
 '<defs><marker id="arrow" markerWidth="8" markerHeight="7" refX="7" refY="3.5" orient="auto" markerUnits="strokeWidth"><path d="M0,0 L7,3.5 L0,7 Z" fill="black"/></marker></defs>',
 '<rect width="1600" height="1080" fill="white"/>'];}
function text(x,y,t,size=26,weight=400,anchor='start',maxWidth=undefined,fill='black'){
 const content=esc(t).replace(/[A-Za-z0-9]+/g,z=>`<tspan font-family="Nimbus Roman, Times New Roman, serif">${z}</tspan>`);
 xml.push(`<text x="${x}" y="${y}" font-family="Droid Sans Fallback, SimSun, sans-serif" font-size="${size}" font-weight="${weight}" fill="${fill}" text-anchor="${anchor}">${content}</text>`);
 allText.push({variant,x,y,text:t,size,weight,anchor,maxWidth});
}
function lines(x,y,ts,size=26,gap=36,anchor='start',maxWidth){ts.forEach((t,i)=>text(x,y+i*gap,t,size,400,anchor,maxWidth));}
function line(x1,y1,x2,y2,weight=2,arrow=false,dash=false){xml.push(`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="black" stroke-width="${weight}" ${arrow?'marker-end="url(#arrow)"':''} ${dash?'stroke-dasharray="7 5"':''}/>`);}
function poly(ps,weight=2,arrow=true){xml.push(`<polyline points="${ps.map(p=>p.join(',')).join(' ')}" fill="none" stroke="black" stroke-width="${weight}" ${arrow?'marker-end="url(#arrow)"':''}/>`);}
function rect(x,y,w,h,{weight=2,dash=false,fill='white',rx=0}={}){xml.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}" stroke="black" stroke-width="${weight}" ${dash?'stroke-dasharray="8 6"':''}/>`);}
function box(x,y,w,h,ts,size=24,{weight=1.8,dash=false}={}){
 rect(x,y,w,h,{weight,dash});
 const a=Array.isArray(ts)?ts:[ts], gap=size*1.35;
 const baseline=y+(h-(a.length-1)*gap)/2+size*.33;
 lines(x+w/2,baseline,a,size,gap,'middle',w-14);
}
function sectionTitle(){text(58,66,'三项研究内容及其递进关系',42,600);line(58,91,1542,91,2);}
function foundation(y=1008){rect(58,y-28,1484,60,{weight:1.5});text(800,y+11,'共同基础：工艺与人员约束，工序—站位—团队联合决策，可行性检查',27,400,'middle',1450);}
function graph(x,y,w,h,hetero=false){
 const pts=[['工序',.12,.27,0],['工序',.56,.2,0],['站位',.88,.4,1],['技能',.42,.68,2],['工人',.79,.85,3],['工人',.08,.85,3]];
 const edges=[[0,1],[1,2],[0,3],[3,4],[3,5],[4,2],[5,0],[1,3]];
 for(const [a,b] of edges)line(x+pts[a][1]*w,y+pts[a][2]*h,x+pts[b][1]*w,y+pts[b][2]*h,1.6,false,hetero&&[a,b].includes(3));
 for(const [t,u,v,k] of pts){const cx=x+u*w,cy=y+v*h;
  if(!hetero||k===0)xml.push(`<circle cx="${cx}" cy="${cy}" r="32" fill="white" stroke="black" stroke-width="1.8"/>`);
  else if(k===1)rect(cx-37,cy-24,74,48,{weight:1.8});
  else if(k===2)xml.push(`<path d="M${cx},${cy-37} L${cx+43},${cy} L${cx},${cy+37} L${cx-43},${cy} Z" fill="white" stroke="black" stroke-width="1.8"/>`);
  else rect(cx-35,cy-24,70,48,{weight:1.8,rx:12});
  text(cx,cy+8,t,23,400,'middle',68);
 }
}
function decisions(x,y,w,h=57,size=23){const gap=25,bw=(w-2*gap)/3;
 ['选工序','选站位','选团队'].forEach((t,i)=>{box(x+i*(bw+gap),y,bw,h,t,size);if(i<2)line(x+i*(bw+gap)+bw+3,y+h/2,x+(i+1)*(bw+gap)-5,y+h/2,1.8,true);});
}
function repair(x,y,w){const bw=(w-28)/2;
 box(x,y,w,50,'工序延迟开工',24);
 poly([[x+w/2,y+50],[x+w/2,y+69],[x+bw/2,y+69],[x+bw/2,y+86]],1.7);
 poly([[x+w/2,y+50],[x+w/2,y+69],[x+bw+28+bw/2,y+69],[x+bw+28+bw/2,y+86]],1.7);
 box(x,y+91,bw,66,['冻结安排','保持不变'],23);
 box(x+bw+28,y+91,bw,66,['可调任务','重新安排'],23);
 poly([[x+bw/2,y+157],[x+bw/2,y+181],[x+w/2,y+181],[x+w/2,y+197]],1.7);
 poly([[x+bw+28+bw/2,y+157],[x+bw+28+bw/2,y+181],[x+w/2,y+181]],1.7,false);
 box(x,y+204,w,50,'修复后的可行计划',24);
}
function planes(x,y,w){const gap=11,n=4,bw=(w-(n-1)*gap)/n;
 const ss=['站位1','站位2','…','站位5'],ps=['飞机A','飞机B','…','飞机E'];
 ss.forEach((t,i)=>{text(x+i*(bw+gap)+bw/2,y+18,t,22,400,'middle',bw);box(x+i*(bw+gap),y+34,bw,49,ps[i],21);});
 const cy=y+111;line(x+bw/2,cy,x+w-bw/2,cy,2);
 ss.forEach((t,i)=>{line(x+i*(bw+gap)+bw/2,y+83,x+i*(bw+gap)+bw/2,cy,1.5);});
 line(x+w/2,cy,x+w/2,cy+24,1.8,true);box(x,y+140,w,49,'各站就绪后共同脉动',23);
}
function levels(x,y,w){const gap=24,ws=[w*.4,(w*.6-2*gap)/2,(w*.6-2*gap)/2];let at=x;
 ['工序／飞机','站位','整线'].forEach((t,i)=>{box(at,y,ws[i],52,t,22);if(i<2)line(at+ws[i]+3,y+26,at+ws[i]+gap-5,y+26,1.7,true);at+=ws[i]+gap;});
}
async function save(name){xml.push('</svg>');const svg=xml.join('\n');fs.writeFileSync(path.join(out,name+'.svg'),svg);await sharp(Buffer.from(svg)).resize(2400,1620).png().toFile(path.join(out,name+'.png'));}

// B1: problem/content/objective matrix enriched with concept drawings.
start('B1_图文对应');sectionTitle();
const xs=[201,659,1117],w=425;
text(61,298,'研究问题',27,600,'start',124);text(61,590,'研究内容',27,600,'start',124);text(61,877,'关注目标',27,600,'start',124);
const titles=[['研究一','无扰动联合静态调度'],['研究二','异构图联合调度与重调度'],['研究三','多架次协同动态调度']];
const qs=[['如何联合安排工序、','站位与人员团队？'],['如何区分不同关系，','并修复受扰计划？'],['如何协调多架飞机的','实际进度与共同脉动？']];
for(let i=0;i<3;i++){
 rect(xs[i],143,w,791,{dash:true,weight:2});text(xs[i]+w/2,181,titles[i][0],29,600,'middle',w-25);text(xs[i]+w/2,219,titles[i][1],i===1?27:28,600,'middle',w-25);
 line(xs[i],240,xs[i]+w,240,1.4);lines(xs[i]+w/2,285,qs[i],26,38,'middle',w-35);line(xs[i],343,xs[i]+w,343,1.4);
}
text(xs[0]+w/2,389,'同构图统一表示',28,600,'middle',w-25);graph(xs[0]+57,414,315,170,false);
text(xs[0]+w/2,617,'共享图传播规则',23,400,'middle',w-30);line(xs[0]+w/2,636,xs[0]+w/2,663,1.8,true);decisions(xs[0]+27,680,w-54,61,23);
text(xs[0]+w/2,785,'联合构造可行排程',26,400,'middle',w-25);
text(xs[1]+w/2,389,'异构图区分实体与关系',28,600,'middle',w-25);repair(xs[1]+41,419,w-82);
text(xs[1]+w/2,721,'利用前序、技能与占用关系',24,400,'middle',w-25);text(xs[1]+w/2,763,'联合安排并保留既有承诺',24,400,'middle',w-25);
text(xs[2]+w/2,389,'语义增强多架次状态',28,600,'middle',w-25);planes(xs[2]+41,414,w-82);
levels(xs[2]+23,640,w-46);text(xs[2]+w/2,726,'融合实际进度与时间后果',24,400,'middle',w-25);text(xs[2]+w/2,767,'协调当前与紧邻下一周期',24,400,'middle',w-25);
for(let i=0;i<3;i++)line(xs[i],817,xs[i]+w,817,1.4);
lines(xs[0]+w/2,864,['排程质量','可行性与推理成本'],26,39,'middle',w-25);
lines(xs[1]+w/2,864,['完工效率','计划稳定性'],26,39,'middle',w-25);
lines(xs[2]+w/2,864,['整批工期','周期等待与计划偏离'],26,39,'middle',w-25);
line(626,187,651,187,2.4,true);line(1084,187,1109,187,2.4,true);
text(642,119,'关系区分与扰动响应',24,400,'middle',410);text(1100,119,'多架次实际状态与共同脉动',24,400,'middle',425);
foundation();await save('三项研究关系_B1_图文对应_20261008');

// B2: nested research frames, borrowing the supplied overview's grouped layout.
// Only study 1 -> study 2 -> study 3 is connected; this is not a parallel fork.
start('B2_分组总览');sectionTitle();
rect(58,130,1484,274,{dash:true,weight:2.2});text(800,170,'研究一：同构图支持的无扰动联合静态调度',31,600,'middle',1400);line(58,190,1542,190,1.4);
lines(92,243,['研究问题','工序、站位与团队','如何联合安排？'],27,42,'start',290);line(388,206,388,384,1.4);
graph(419,203,270,157,false);text(557,381,'共享图传播',22,400,'middle',280);line(735,289,780,289,2,true);decisions(797,247,385,76,24);
text(989,359,'同一状态下的条件联合选择',24,400,'middle',410);line(1211,206,1211,384,1.4);
lines(1250,244,['研究目标','形成可行排程','评价质量与计算成本'],26,42,'start',270);
line(409,412,409,483,3,true);text(446,452,'一到二：关系区分与扰动响应',25,400,'start',650);
text(876,452,'二到三：多架次实际状态与共同脉动',25,400,'start',654);
const lx=58,rx=842,bw=700,yy=494,hh=440;
rect(lx,yy,bw,hh,{dash:true,weight:2.2});rect(rx,yy,bw,hh,{dash:true,weight:2.2});
text(lx+bw/2,536,'研究二：异构图联合调度与重调度',29,600,'middle',bw-30);line(lx,555,lx+bw,555,1.4);
text(lx+bw/2,593,'区分不同关系，并修复延迟开工后的计划',26,400,'middle',bw-35);
graph(lx+44,638,253,159,true);text(lx+174,840,'实体与关系分别表示',23,400,'middle',300);
line(lx+326,731,lx+359,731,2,true);
box(lx+373,632,292,61,['冻结安排保留','可调任务修复'],23);
line(lx+519,697,lx+519,722,1.8,true);box(lx+373,734,292,62,'联合安排与计划调整',24);
line(lx+25,859,lx+bw-25,859,1.4);text(lx+bw/2,908,'关注完工效率与计划稳定性',27,400,'middle',bw-35);
text(rx+bw/2,536,'研究三：语义增强的多架次协同调度',29,600,'middle',bw-30);line(rx,555,rx+bw,555,1.4);
text(rx+bw/2,593,'理解多架飞机的实际进度及其共同时间影响',26,400,'middle',bw-35);
planes(rx+37,626,324);line(rx+377,731,rx+410,731,2,true);
box(rx+426,633,239,60,['分层状态融合','随生产事件更新'],23);line(rx+545.5,697,rx+545.5,722,1.8,true);
box(rx+426,734,239,62,['进度与时间后果','支持协同安排'],23);
line(rx+25,859,rx+bw-25,859,1.4);text(rx+bw/2,908,'关注当前、下一周期及整批执行',27,400,'middle',bw-35);
line(771,731,829,731,4,true);foundation();await save('三项研究关系_B2_分组总览_20261008');

// B3: vertical progression with aligned question/content/objective columns.
start('B3_纵向递进');sectionTitle();
text(212,123,'研究问题',26,600,'middle',280);text(828,123,'核心研究内容',26,600,'middle',720);text(1396,123,'关注目标',26,600,'middle',245);
const ys=[145,425,705];
for(let i=0;i<3;i++){
 rect(58,ys[i],1484,239,{dash:true,weight:2});line(363,ys[i],363,ys[i]+239,1.4);line(1251,ys[i],1251,ys[i]+239,1.4);
 text(91,ys[i]+44,'研究'+['一','二','三'][i],29,600,'start',248);
}
lines(91,ys[0]+91,['无扰动条件下','工序、站位与团队','如何联合安排？'],25,40,'start',256);
box(408,ys[0]+63,266,97,['同构图统一表示','共享图传播规则'],26);line(689,ys[0]+111,733,ys[0]+111,2.3,true);decisions(751,ys[0]+84,459,61,25);
text(940,ys[0]+190,'联合构造可行排程',26,400,'middle',490);
lines(1277,ys[0]+94,['排程质量','可行性','推理成本'],26,40,'start',236);
line(211,391,211,417,2.8,true);text(385,412,'一到二：进一步区分关系，并响应工序延迟开工',25,400,'start',1140);
lines(91,ys[1]+91,['不同关系如何利用？','受扰后如何兼顾','效率与计划稳定性？'],25,40,'start',256);
box(408,ys[1]+65,266,96,['异构图关系表示','前序、技能与占用'],26);line(689,ys[1]+113,735,ys[1]+113,2.3,true);
box(751,ys[1]+47,244,64,'保留冻结安排',25);box(751,ys[1]+139,244,64,'修复可调任务',25);
poly([[997,ys[1]+79],[1032,ys[1]+79],[1032,ys[1]+126],[1048,ys[1]+126]],1.8);
poly([[997,ys[1]+171],[1032,ys[1]+171],[1032,ys[1]+126]],1.8,false);
box(1058,ys[1]+90,156,74,['形成合法','调整计划'],25);
lines(1277,ys[1]+110,['完工效率','计划稳定性'],26,42,'start',236);
line(211,671,211,697,2.8,true);text(385,692,'二到三：进一步理解多架次实际状态与共同脉动',25,400,'start',1140);
lines(91,ys[2]+91,['多架飞机进度不同','如何协调共同脉动','与后续周期？'],25,40,'start',256);
levels(408,ys[2]+46,589);
poly([[1001,ys[2]+72],[1050,ys[2]+72],[1050,ys[2]+124]],1.8);
box(1066,ys[2]+45,147,137,['语义增强','协同安排'],25);
box(408,ys[2]+132,270,61,'实际进度与最近变化',24);line(686,ys[2]+162,723,ys[2]+162,1.8,true);
box(734,ys[2]+132,300,61,'当前与下一周期时间后果',23);line(1038,ys[2]+162,1056,ys[2]+162,1.7,true);
lines(1277,ys[2]+94,['整批工期','周期等待','计划偏离'],26,40,'start',236);
foundation();await save('三项研究关系_B3_纵向递进_20261008');
fs.writeFileSync(path.join(root,'qa/diagram_text_positions.json'),JSON.stringify(allText,null,2));
console.log('Created 3 SVG diagrams and 3 PNG previews.');
