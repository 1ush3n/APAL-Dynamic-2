"""Apply the nineteen approved comment proposals, preserving package comments.

The seven unresolved proposals are recorded, not implemented.  This script
patches only document.xml and styles.xml so the user's drawings, relationships,
comment text, and other document parts survive byte-for-byte.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

from lxml import etree as E

ROOT = Path(__file__).resolve().parent
SOURCE = next((ROOT / "reference/开题报告和工作三").glob("*.docx"))
OUT = ROOT / "deliverables"
OUT.mkdir(exist_ok=True)
DEST = OUT / "开题报告_批注修订稿_20261010.docx"
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
NS = {"w": W, "m": M, "v": "urn:schemas-microsoft-com:vml"}
qn = lambda s: "{" + (W if s.startswith("w:") else M) + "}" + s[2:]

with ZipFile(SOURCE) as z:
    package = {i.filename: z.read(i.filename) for i in z.infolist()}
doc = E.fromstring(package["word/document.xml"])
styles = E.fromstring(package["word/styles.xml"])
body = doc.find(qn("w:body"))
paras = doc.xpath("//w:body//w:p", namespaces=NS)
text_of = lambda p: "".join(p.xpath(".//w:t/text()", namespaces=NS))
before = [text_of(p) for p in paras]
changes = []


def ensure(parent, tag):
    el = parent.find(qn(tag))
    if el is None:
        el = E.SubElement(parent, qn(tag))
    return el


def comment_ranges(p):
    pos, starts, spans = 0, {}, {}
    for el in p.iter():
        if el.tag == qn("w:commentRangeStart"):
            starts[el.get(qn("w:id"))] = pos
        elif el.tag == qn("w:commentRangeEnd"):
            cid = el.get(qn("w:id"))
            spans[cid] = (starts[cid], pos)
        elif el.tag == qn("w:t"):
            pos += len(el.text or "")
    return spans


def set_text(i, text, proposals, anchors=None):
    """Rebuild a text paragraph, relocating all its original comment ranges."""
    p, old = paras[i], text_of(paras[i])
    ranges = comment_ranges(p)
    anchors = anchors or {}
    rpr = p.find(".//" + qn("w:rPr"))
    rpr = copy.deepcopy(rpr) if rpr is not None else None
    if rpr is not None:
        # Position offsets were used to align the old equation pictures; they
        # must not lower the new prose relative to native mathematical runs.
        for tag in ("w:position", "w:vertAlign"):
            for el in rpr.findall(qn(tag)):
                rpr.remove(el)
    events = {}
    for cid, (a, b) in ranges.items():
        anchor = anchors.get(cid, old[a:b])
        start = text.find(anchor) if anchor else -1
        if start < 0:
            start, end = 0, len(text)
        else:
            end = start + len(anchor)
        events.setdefault(start, []).append(("start", cid, end - start))
        events.setdefault(end, []).append(("end", cid, end - start))
    for ch in list(p):
        if ch.tag != qn("w:pPr"):
            p.remove(ch)
    points = sorted({0, len(text), *events})
    for j, pos in enumerate(points):
        for typ, cid, length in sorted(events.get(pos, []), key=lambda a: (a[0] != "end", a[2] if a[0] == "end" else -a[2])):
            marker = E.SubElement(p, qn("w:commentRangeEnd" if typ == "end" else "w:commentRangeStart"))
            marker.set(qn("w:id"), cid)
            if typ == "end":
                rr = E.SubElement(p, qn("w:r"))
                rp = E.SubElement(rr, qn("w:rPr"))
                E.SubElement(rp, qn("w:rStyle")).set(qn("w:val"), "CommentReference")
                E.SubElement(rr, qn("w:commentReference")).set(qn("w:id"), cid)
        if j + 1 < len(points) and points[j + 1] > pos:
            rr = E.SubElement(p, qn("w:r"))
            if rpr is not None:
                rr.append(copy.deepcopy(rpr))
            tt = E.SubElement(rr, qn("w:t"))
            tt.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            tt.text = text[pos:points[j + 1]]
    changes.append({"source_paragraph": i, "proposals": proposals, "before": old, "after": text})


# Text changes. The unresolved seven proposals are intentionally excluded.
set_text(11, before[11].replace("工序延迟开工和多架次连续装配的情况", "工序延迟开工（即扰动使尚未开工工序的最早可开工时刻推迟）和多架次连续装配的情况"), [8, 15])
set_text(14, before[14].replace("本研究采用五个串行站位", "本课题依据调研工厂的五站位脉动装配线开展研究"), [5], {"4": "本课题依据调研工厂的五站位脉动装配线开展研究"})
set_text(17, "在给定工艺和人员条件下，调度需要共同确定工序安排顺序、执行站位和具体人员团队，即执行某道工序的人员组合。工序选择影响后续作业的安排条件；站位分配影响各站任务分布和可选人员；团队成员的资格、效率及占用影响工序能否执行和作业时长。人员首次被指派到某站位后，在当前阶段保持该站位绑定，其后续能够承担的工序也因此受到限制。例如，为一项作业选择人员后，这些人员在相应时间段内无法承担其他作业；将工序分配到下游站位，还须保证其后继工序的站位顺序符合工艺前序。各项选择由此相互影响，单独确定某一项后再处理其他项，可能压缩后续安排的可行空间。", [6, 15], {"5": "站位分配影响各站任务分布和可选人员"})
set_text(20, "1.3 扰动影响与多架次协同调度", [9])
set_text(21, before[21].replace("本课题关注工序延迟开工，即尚未开工工序的开工可用性发生延迟。", "在动态调度研究中，本课题关注工序延迟开工，即扰动使尚未开工工序的最早可开工时刻推迟。"), [8, 9], {"8": "在动态调度研究中，本课题关注工序延迟开工，即扰动使尚未开工工序的最早可开工时刻推迟。"})
set_text(22, "基准排程是用于安排生产并评价后续计划改动的参照排程。" + before[22], [15])
set_text(23, "记第q个实际周期的占用站位集合为〖Kq〗，站位k首次完成本站当前有效任务并满足转站条件的时刻为〖Fkq〗，则共同脉动时刻〖Pq〗及实际周期长度〖Hq〗为：", [11, 12], {"10": "记第q个实际周期的占用站位集合"})
set_text(25, "共同转站时刻由最晚就绪的站位决定。局部工序延迟若推迟了这一时刻，其他在制飞机的转站及下一架飞机的投产也会相应推迟。本课题将无扰动基准排程确定的计划周期长度称为基准节拍〖H0〗，用于评价实际生产进度的偏离；实际转站仍由各站位的就绪情况决定。", [12, 13, 14, 15], {"12": "共同转站时刻由最晚就绪的站位决定。局部工序延迟若推迟了这一时刻，其他在制飞机的转站及下一架飞机的投产也会相应推迟。", "13": "共同转站时刻由最晚就绪的站位决定。", "14": "本课题将无扰动基准排程确定的计划周期长度称为基准节拍〖H0〗，用于评价实际生产进度的偏离"})
set_text(28, before[28].replace("计划稳定性的动态重调度", "计划稳定性（以相对于基准排程的改动程度评价）的动态重调度"), [15])
set_text(34, before[34].replace("Bao等研究给定站位数量下的飞机总装线平衡，将任务分站、资源约束与并行调度结合，用本站任务的最大完成时间评价周期，并同时考虑负荷平衡和资源投入[6]。", "Bao等针对给定站位数量的飞机总装线，联合研究工序分站与资源约束下的并行任务调度，以各站位任务的最大完成时间评价周期，并考虑负荷平衡和资源投入[6]。"), [18])
set_text(35, before[35].replace("本课题在当前阶段保留人员站位绑定，所需人数给定，还要考虑具体成员的资格与效率差异。", ""), [19], {"18": "两项研究分别涉及阶段末调整和周期内绑定。"})
set_text(36, before[36].replace("本课题采用串行单向站位和阶段内人员绑定，研究工艺前序及现有资源约束下的工序、站位与团队联合安排。", "本课题在给定工序需求人数和人员资格、效率条件下，联合确定工序安排顺序、执行站位和具体团队。人员所属站位随首次指派形成，并在当前阶段保持。因此，工序分站不仅改变各站任务分布，也会影响人员选择和后续可行安排。"), [19])
set_text(56, before[56].replace("强化学习将调度组织为连续的状态—动作过程，通过奖励学习选择策略。", "近年来，强化学习被用于学习调度中的工序选择和派工策略[24,27]。这类方法将调度表示为序贯决策过程，根据生产状态选择动作，并通过奖励反馈学习策略。"), [21], {"20": "近年来，强化学习被用于学习调度中的工序选择和派工策略[24,27]。这类方法将调度表示为序贯决策过程，根据生产状态选择动作，并通过奖励反馈学习策略。"})
set_text(87, before[87].replace("工序前序和资源关联具有图结构，用图表示可以将作业属性与关系共同组织到状态中。", "近年来，图神经网络被用于编码工序前序和资源关联，并与强化学习结合进行调度决策[24,28,29]。"), [22])
set_text(91, before[91].replace("工艺前序决定执行先后，人员资格决定技能可行性，资源占用决定时间冲突，站位归属决定作业位置。这些关系作用不同，异构图可以通过实体和关系类型组织相应信息。", "调度状态中的工艺与资源关系具有不同含义：工艺前序限定执行先后，人员资格限定技能匹配，资源占用反映时间冲突，站位归属约束作业位置。异构图通过区分实体与关系类型，分别组织这些信息。"), [23], {"22": "调度状态中的工艺与资源关系具有不同含义：工艺前序限定执行先后，人员资格限定技能匹配，资源占用反映时间冲突，站位归属约束作业位置。异构图通过区分实体与关系类型，分别组织这些信息。"})
set_text(129, "3 研究内容", [24])
set_text(136, before[136].replace("站位分配影响任务分布和人员绑定", "站位分配影响各站任务分布和可选人员，人员首次指派形成当前阶段的站位绑定"), [6])
set_text(149, "4 研究方案及技术路线", [25])
set_text(151, before[151] + "工序标准工时已包含分摊的转站等耗时，计算排程时间时不再重复增加该部分时间。", [11])

# Native Office Math: do not copy the source's corrupted compatibility XML or
# its duplicated inline equation objects. These expressions retain the existing
# definitions and labels exactly.
def mr(text, plain=False):
    r = E.Element(qn("m:r"))
    if plain:
        E.SubElement(E.SubElement(r, qn("m:rPr")), qn("m:sty")).set(qn("m:val"), "p")
    rp = E.SubElement(r, qn("w:rPr"))
    ff = E.SubElement(rp, qn("w:rFonts"))
    for key in ("ascii", "hAnsi", "eastAsia", "cs"):
        ff.set(qn("w:" + key), "Cambria Math")
    E.SubElement(rp, qn("w:sz")).set(qn("w:val"), "24")
    tt = E.SubElement(r, qn("m:t")); tt.text = text
    tt.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    return r


def script(base, sub, sup=None):
    obj = E.Element(qn("m:sSubSup" if sup else "m:sSub"))
    E.SubElement(obj, qn("m:e")).append(mr(base) if isinstance(base, str) else base)
    E.SubElement(obj, qn("m:sub")).append(mr(sub))
    if sup:
        E.SubElement(obj, qn("m:sup")).append(mr(sup, plain=True))
    return obj


def hat(base):
    obj = E.Element(qn("m:acc"))
    E.SubElement(E.SubElement(obj, qn("m:accPr")), qn("m:chr")).set(qn("m:val"), "̂")
    E.SubElement(obj, qn("m:e")).append(mr(base))
    return obj


def math(items):
    obj = E.Element(qn("m:oMath"))
    for item in items:
        obj.append(item)
    return obj


def frac(numer, denom):
    f = E.Element(qn("m:f"))
    for tag, items in [("m:num", numer), ("m:den", denom)]:
        e = E.SubElement(f, qn(tag))
        for item in items:
            e.append(item)
    return f


def named_math(name):
    if name == "heur":
        return math([script(hat("P"), "q", "heur"), mr("("), script("s", "n"), mr(")")])
    values = {"Kq": ("K", "q"), "Fkq": ("F", "k,q"), "Pq": ("P", "q"), "Hq": ("H", "q"), "H0": ("H", "0"), "sn": ("s", "n")}
    return math([script(*values[name])])


def insert_placeholders(p):
    for r in list(p.findall(qn("w:r"))):
        t = r.find(qn("w:t"))
        if t is None or "〖" not in (t.text or ""):
            continue
        segments = re.split(r"(〖[^〗]+〗)", t.text)
        at = p.index(r)
        p.remove(r)
        for seg in segments:
            if not seg:
                continue
            if seg.startswith("〖"):
                item = named_math(seg[1:-1])
            else:
                item = copy.deepcopy(r)
                item.find(qn("w:t")).text = seg
            p.insert(at, item); at += 1


for i in (23, 25):
    insert_placeholders(paras[i])

# The old inline objects are enclosed in INCLUDEPICTURE field instructions.
# Rebuild these two paragraphs as plain text plus math so no stale field can
# suppress the native inline formula in Word or LibreOffice.
set_text(201, "对于周期q中保存的状态〖sn〗，记当时的启发式脉动估计为〖heur〗，实际脉动时刻为〖Pq〗，当前标签为：", [12])
set_text(203, "紧邻下一周期站位k的标签，以本次实际脉动〖Pq〗加基准节拍〖H0〗为参照：", [12])
for i in (201, 203):
    insert_placeholders(paras[i])

limit = E.Element(qn("m:limLow"))
E.SubElement(limit, qn("m:e")).append(mr("max", plain=True))
low = E.SubElement(limit, qn("m:lim"))
low.append(mr("k")); low.append(mr("∈", plain=True)); low.append(script("K", "q"))
equations = {
    24: math([script("P", "q"), mr("="), limit, script("F", "k,q"), mr(",    "), script("H", "q"), mr("="), script("P", "q"), mr("−"), script("P", "q−1")]),
    202: math([script("y", "n", "cur"), mr("="), frac([script("P", "q"), mr("−"), script(hat("P"), "q", "heur"), mr("("), script("s", "n"), mr(")")], [script("H", "0")])]),
    204: math([script("y", "n,k", "next"), mr("="), frac([script("F", "k,q+1"), mr("−"), script("P", "q"), mr("−"), script("H", "0")], [script("H", "0")])]),
}
for i, eq in equations.items():
    p = paras[i]
    oldruns = [r for r in p if r.tag == qn("w:r") and r.xpath(".//v:shape[@equationxml]", namespaces=NS)]
    assert len(oldruns) == 1
    position = p.index(oldruns[0]); p.remove(oldruns[0])
    wrap = E.Element(qn("m:oMathPara"))
    E.SubElement(E.SubElement(wrap, qn("m:oMathParaPr")), qn("m:jc")).set(qn("m:val"), "center")
    wrap.append(eq); p.insert(position, wrap)

# Remove the title's one manual line break. Automatic wrapping remains intact.
for br in paras[7].xpath(".//w:br", namespaces=NS):
    br.getparent().remove(br)
changes.append({"source_paragraph": 7, "proposals": [2], "before": before[7], "after": text_of(paras[7]), "detail": "删除手动换行，题目文字不变"})

# Move complete top-level chapter blocks, including the progress table.
basis = paras[265]; progress = paras[276]; outcomes = paras[305]
children = list(body)
b, p, e = children.index(basis), children.index(progress), children.index(outcomes)
assert b < p < e
basis_block, progress_block = children[b:p], children[p:e]
for el in children[b:e]:
    body.remove(el)
for el in progress_block + basis_block:
    body.insert(b, el); b += 1
set_text(276, "6 研究进度安排", [26])
set_text(265, "7 研究基础与可行性分析", [26])
for i in (266, 270, 274):
    set_text(i, re.sub(r"^6\.", "7.", before[i]), [26])


def set_fonts(rpr, east, halfpoints, bold=None):
    fonts = ensure(rpr, "w:rFonts")
    for a in ("asciiTheme", "hAnsiTheme", "eastAsiaTheme", "cstheme"):
        fonts.attrib.pop(qn("w:" + a), None)
    for a in ("ascii", "hAnsi", "cs"):
        fonts.set(qn("w:" + a), "Times New Roman")
    fonts.set(qn("w:eastAsia"), east)
    for tag in ("w:sz", "w:szCs"):
        ensure(rpr, tag).set(qn("w:val"), str(halfpoints))
    if bold is not None:
        ensure(rpr, "w:b").set(qn("w:val"), "1" if bold else "0")


def paragraph_format(ppr, *, kind, table=False, math=False, figure=False):
    sp = ensure(ppr, "w:spacing")
    ind = ensure(ppr, "w:ind")
    for a in ("firstLine", "firstLineChars", "hanging", "hangingChars", "leftChars", "rightChars"):
        ind.attrib.pop(qn("w:" + a), None)
    ind.set(qn("w:firstLine"), "0")
    if kind in ("chapter", "section", "subsection"):
        before_spacing, after_spacing = {"chapter": (480, 360), "section": (480, 120), "subsection": (240, 120)}[kind]
        sp.set(qn("w:before"), str(before_spacing)); sp.set(qn("w:after"), str(after_spacing))
        sp.set(qn("w:line"), "240"); sp.set(qn("w:lineRule"), "auto")
        ensure(ppr, "w:keepNext").set(qn("w:val"), "1")
        ensure(ppr, "w:keepLines").set(qn("w:val"), "1")
        ensure(ppr, "w:jc").set(qn("w:val"), "center" if kind == "chapter" else "left")
    elif kind == "caption":
        sp.set(qn("w:before"), "120"); sp.set(qn("w:after"), "120")
        sp.set(qn("w:line"), "240"); sp.set(qn("w:lineRule"), "auto")
        ensure(ppr, "w:jc").set(qn("w:val"), "center")
    elif kind == "reference":
        sp.set(qn("w:before"), "0"); sp.set(qn("w:after"), "0")
        sp.set(qn("w:line"), "320"); sp.set(qn("w:lineRule"), "atLeast")
        ensure(ppr, "w:jc").set(qn("w:val"), "both")
    elif kind == "displaymath":
        sp.set(qn("w:before"), "100"); sp.set(qn("w:after"), "100")
        sp.set(qn("w:line"), "400"); sp.set(qn("w:lineRule"), "atLeast")
        ensure(ppr, "w:jc").set(qn("w:val"), "center")
        ensure(ppr, "w:keepNext").set(qn("w:val"), "1")
    else:
        sp.set(qn("w:before"), "0"); sp.set(qn("w:after"), "0")
        sp.set(qn("w:line"), "400"); sp.set(qn("w:lineRule"), "atLeast" if math or figure else "exact")
        ensure(ppr, "w:jc").set(qn("w:val"), "both")
        if not table and not figure:
            ind.set(qn("w:firstLine"), "480"); ind.set(qn("w:firstLineChars"), "200")
    ensure(ppr, "w:widowControl").set(qn("w:val"), "1")


for sid, kind, size, east in [("a", "body", 24, "宋体"), ("1", "chapter", 32, "黑体"), ("21", "section", 30, "黑体"), ("31", "subsection", 28, "黑体")]:
    style = styles.xpath("//w:style[@w:styleId=$sid]", namespaces=NS, sid=sid)[0]
    set_fonts(ensure(style, "w:rPr"), east, size, bold=kind != "body")
    paragraph_format(ensure(style, "w:pPr"), kind=kind)

for i, p in enumerate(paras):
    # Preserve the master's supplied front-page fields/instructions. Only the
    # title's font names are normalized; its existing size is retained.
    if i < 8:
        if i in (5, 7):
            for r in p.findall(qn("w:r")):
                set_fonts(ensure(r, "w:rPr"), "黑体", 36, bold=True)
        continue
    text = text_of(p)
    sid = p.xpath("./w:pPr/w:pStyle/@w:val", namespaces=NS)
    sid = sid[0] if sid else None
    table = bool(p.xpath("ancestor::w:tc", namespaces=NS))
    displaymath = bool(p.find(qn("m:oMathPara")) is not None)
    math_here = bool(p.xpath(".//m:oMath", namespaces=NS))
    figure = bool(p.xpath(".//w:drawing|.//w:pict", namespaces=NS))
    if sid in ("1", "21", "31"):
        kind, east, size = {"1": ("chapter", "黑体", 32), "21": ("section", "黑体", 30), "31": ("subsection", "黑体", 28)}[sid]
    elif re.match(r"^(?:图|表)\d+\s", text) and not table:
        kind, east, size = "caption", "宋体", 21
    elif re.match(r"^\[\d+\]", text):
        kind, east, size = "reference", "宋体", 21
    elif displaymath:
        kind, east, size = "displaymath", "宋体", 24
    else:
        kind, east, size = "body", "宋体", 24
    ppr = p.find(qn("w:pPr"))
    if ppr is None:
        ppr = E.Element(qn("w:pPr")); p.insert(0, ppr)
    paragraph_format(ppr, kind=kind, table=table, math=math_here, figure=figure)
    set_fonts(ensure(ppr, "w:rPr"), east, size, bold=True if kind in ("chapter", "section", "subsection") else None)
    for r in p.findall(qn("w:r")):
        set_fonts(ensure(r, "w:rPr"), east, size, bold=True if kind in ("chapter", "section", "subsection") else None)
    # Keep the figure with its caption; table captions with the following table.
    if figure or (kind == "caption" and text.startswith("表")):
        ensure(ppr, "w:keepNext").set(qn("w:val"), "1")
    if table:
        # Avoid accidental inheritance of heading spacing into table cells.
        ensure(ppr, "w:keepNext").set(qn("w:val"), "0")

# Rows may grow as the selected font metrics change, rather than clip text.
for height in doc.xpath("//w:trHeight[@w:hRule='exact']", namespaces=NS):
    height.set(qn("w:hRule"), "atLeast")

# Structural verification before the render step.
expected_ids = set(E.fromstring(package["word/comments.xml"]).xpath("//w:comment/@w:id", namespaces=NS))
for selector in ("//w:commentRangeStart/@w:id", "//w:commentRangeEnd/@w:id", "//w:commentReference/@w:id"):
    actual = doc.xpath(selector, namespaces=NS)
    assert set(actual) == expected_ids, (selector, actual, expected_ids)
    assert all(n == 1 for n in Counter(actual).values()), selector
assert len(doc.xpath("//m:oMath", namespaces=NS)) == 13
assert not doc.xpath("//v:shape[@equationxml]", namespaces=NS)
assert not paras[7].xpath(".//w:br", namespaces=NS)
assert text_of(paras[7]) == before[7]
for i in (19, 26, 33, 37):
    assert text_of(paras[i]) == before[i], f"unresolved text changed at {i}"
assert "瞬时转站模型" not in "".join(doc.xpath("//w:t/text()", namespaces=NS))
assert "36个固定物料延迟场景" in text_of(paras[170])
assert "其物料延迟实验" in text_of(paras[268])

package["word/document.xml"] = E.tostring(doc, xml_declaration=True, encoding="UTF-8", standalone=True)
package["word/styles.xml"] = E.tostring(styles, xml_declaration=True, encoding="UTF-8", standalone=True)
with ZipFile(DEST, "w", ZIP_DEFLATED) as z:
    for name, data in package.items():
        z.writestr(name, data)
with ZipFile(SOURCE) as a, ZipFile(DEST) as b:
    unchanged = [n for n in a.namelist() if n not in ("word/document.xml", "word/styles.xml")]
    assert all(a.read(n) == b.read(n) for n in unchanged)

approved = [1, 2, 5, 6, 8, 9, 11, 12, 13, 14, 15, 18, 19, 21, 22, 23, 24, 25, 26]
pending = [3, 4, 7, 10, 16, 17, 20]
manifest = {
    "input": str(SOURCE), "output": str(DEST),
    "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "output_sha256": hashlib.sha256(DEST.read_bytes()).hexdigest(),
    "approved_items": approved, "pending_items": pending,
    "comments_preserved": len(expected_ids), "native_equations": 13,
    "unchanged_package_parts": len(unchanged), "changed_package_parts": ["word/document.xml", "word/styles.xml"],
    "changes": changes,
    "render_status": "pending",
}
(OUT / "revision_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")

# The global disturbance wording is item 10 and remains pending. Inventory all
# locations now, without blindly replacing literature or label-delay terms.
section = ""
inventory = []
for p in doc.xpath("//w:body//w:p", namespaces=NS):
    text = text_of(p)
    if re.match(r"^\d+(?:\.\d+)*\s", text):
        section = text
    if re.search(r"延迟|扰动|开工可用性|物料释放|最早可开工", text):
        category = "本课题表述／核对后同步"
        if re.search(r"标签延迟|标签延后", text):
            category = "标签结算时间／不改为开工扰动"
        elif re.match(r"^\[\d+\]", text):
            category = "参考文献名称／保持原名"
        elif re.search(r"Zhu等|Lovato|Battaia|Chen等|Hu等|Herroelen", text) and not re.search(r"本课题|研究内容", text):
            category = "他人文献／保留实际研究的扰动"
        elif "36个" in text or "其物料延迟实验" in text:
            category = "已有实验事实／待最新论文核实"
        inventory.append({"section": section, "text": text, "category": category})
(OUT / "disturbance_wording_inventory.json").write_text(json.dumps(inventory, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps({"output": str(DEST), "approved": len(approved), "pending": pending, "comments": len(expected_ids), "native_equations": 13, "unchanged_parts": len(unchanged), "disturbance_locations": len(inventory)}, ensure_ascii=False))
