"""Record completed page review and package this round's revision evidence."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import re
import fitz
from lxml import etree

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "deliverables"
WORD = OUT / "开题报告_批注修订稿_20261010.docx"
RECORD = OUT / "开题报告_已确认修订与扰动口径待核对_20261010.md"
MANIFEST = OUT / "confirmed_text_manifest.json"
PREVIOUS_ARCHIVE = ROOT.parent / "report_revision_20261010_1020/deliverables/开题报告_20261010修订依据与脚本.zip"
ARCHIVE = OUT / PREVIOUS_ARCHIVE.name

manifest = json.loads(MANIFEST.read_text())
assert hashlib.sha256(WORD.read_bytes()).hexdigest() == manifest["output_sha256"]
pdf_path = ROOT / "rendered_confirmed/开题报告_批注修订稿_20261010.pdf"
pdf = fitz.open(pdf_path)
assert len(pdf) == 30
unchanged_pages = [1, 20, 22, 23, 24, 26, 27]
reviewed_pages = [n for n in range(1, 31) if n not in unchanged_pages]
page_hashes = {}
for n in range(1, 31):
    png = ROOT / f"rendered_confirmed/page-{n}.png"
    page_hashes[str(n)] = hashlib.sha256(png.read_bytes()).hexdigest()
    if n in unchanged_pages:
        old_png = ROOT / f"rendered_final/page-{n}.png"
        assert page_hashes[str(n)] == hashlib.sha256(old_png.read_bytes()).hexdigest()

with ZipFile(WORD) as z:
    doc = etree.fromstring(z.read("word/document.xml"))
ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
paras = ["".join(p.itertext()) for p in doc.xpath("//w:p", namespaces=ns)]
refs = [int(m.group(1)) for t in paras if (m := re.match(r"^\[(\d+)\]", t))]
assert refs == list(range(1, 42)), refs
assert "2.1.2 工序延迟开工下的重调度" in paras
manifest["render_qa"] = {
    "page_count": 30,
    "pages_visually_reviewed_this_pass": reviewed_pages,
    "pages_identical_to_previously_reviewed_render": unchanged_pages,
    "result": "章节、图表、公式、页码及参考文献完整显示；未见裁切或重叠。",
    "pdf_sha256": hashlib.sha256(pdf_path.read_bytes()).hexdigest(),
    "page_png_sha256": page_hashes,
}
MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")

s = RECORD.read_text()
s = s.replace(
    "- 页面核查：等待本轮最终渲染检查。",
    "- 页面核查：最终稿共30页。本轮逐页检查23张发生变化的页面，另7页与已经核查的前版渲染完全一致；正文、图表、公式、页码和参考文献完整显示，未见裁切或重叠。",
)
s = s.replace(
    "## 附录：扰动相关位置逐段检查清单\n\n本清单用于后续逐处核对，不是批量替换指令。完整原句保留，便于辨别生产扰动、文献中的其他不确定性与监督标签的结算延迟。",
    "## 附录：第10项待核对位置的历史检索快照\n\n本清单保留本轮改动前的检索原句，仅供第10项后续定位，不代表现行正文，也不是批量替换指令。其中2.1.2的旧标题及旧引用编号已在现行Word中更新；当前标题为“2.1.2 工序延迟开工下的重调度”，现行引用以Word为准。保留原句用于辨别生产扰动、文献中的其他不确定性与监督标签的结算延迟。",
)
RECORD.write_text(s)

readme = OUT / "本轮修订重放说明.md"
readme.write_text("""# 2026年10月10日本轮文字修订记录

修订链：前轮批注修订稿 → add_section14.py → apply_confirmed_text.py → 最终Word。

add_section14.py补入1.4具体研究价值，并保留两段原文；apply_confirmed_text.py落实五站位说明、平衡与调度、后移引用以及2.1.2标题和末段，保留公式及批注。update_confirmations.py更新确认记录、术语表和来源说明。finalize_qa_and_archive.py记录最终页面核查，并将本轮依据附加到前轮脚本存档中。脚本中的目录常量对应本次工作环境；移至其他目录时应先调整路径。

本轮最终Word的SHA256见confirmed_text_manifest.json。最终稿30页，保留26条批注和13个原生数学对象。新工业案例为参考文献[9]，原[9]—[40]已顺延为[10]—[41]。第10项扰动口径及既有实验事实的全面核对仍单独保留，未更改36个既有实验场景。旧存档内的确认记录是历史版本，现行状态以本轮记录为准。

正文、标题、参考文献及说明以本轮用户确认范围为准。工作一、二既定题名及已有实验事实未作更改。
""")

new_files = {
    "section14/add_section14.py": ROOT / "add_section14.py",
    "section14/section14_manifest.json": OUT / "section14_manifest.json",
    "confirmed/apply_confirmed_text.py": ROOT / "apply_confirmed_text.py",
    "confirmed/update_confirmations.py": ROOT / "update_confirmations.py",
    "confirmed/finalize_qa_and_archive.py": Path(__file__),
    "confirmed/confirmed_text_manifest.json": MANIFEST,
    "confirmed/开题报告_已确认修订与扰动口径待核对_20261010.md": RECORD,
    "confirmed/开题报告_统一术语与当前定义_20261006.md": OUT / "开题报告_统一术语与当前定义_20261006.md",
    "confirmed/本轮文字修订_来源核查_20261010.md": OUT / "本轮文字修订_来源核查_20261010.md",
    "confirmed/README.md": readme,
}
with ZipFile(PREVIOUS_ARCHIVE) as old, ZipFile(ARCHIVE, "w", ZIP_DEFLATED) as new:
    for item in old.infolist():
        new.writestr(item, old.read(item.filename))
    for arcname, path in new_files.items():
        new.write(path, arcname)
with ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
print(json.dumps({"pages": len(pdf), "reference_count": len(refs), "archive_entries": len(z.namelist()), "word_sha256": manifest["output_sha256"]}, ensure_ascii=False))
