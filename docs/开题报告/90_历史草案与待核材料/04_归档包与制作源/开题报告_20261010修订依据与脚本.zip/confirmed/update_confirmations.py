"""Synchronize the decision record and term reference after user confirmation."""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "deliverables"
manifest = json.loads((OUT / "confirmed_text_manifest.json").read_text())
previous = (OUT / "开题报告_已确认修订与六项待讨论_20261010.md").read_text()
table = previous[previous.index("| 批注方案编号 |"):previous.index("\n原有26条批注")]
lines = table.strip().splitlines()
rows = {}
for line in lines[2:]:
    n = re.match(r"\| (\d+) \|", line)
    if n:
        rows[int(n.group(1))] = line
rows.update({
    4: "| 4 | 改写五站位生产过程 | 1.2分两段说明飞机依次经过五站位，以及各站完成本站安排后同步转站、末站离线和新机投产；保留图1的三站位示意说明。 |",
    7: "| 7 | 自然引入平衡与调度 | 1.2先说明工作量相近不等于完成时间相同，再解释工序分站、作业时间和人员安排之间的关系。 |",
    16: "| 16 | 增补工序后移的工业案例 | 1.3引用Abdinnour的Hawker 800XP案例，直接介绍未完成作业转站后继续安排的生产情况，再交代本课题的有限后移约束；增加新参考文献[9]并同步调整后续编号。 |",
    17: "| 17 | 统一平衡与调度的定义 | 装配线平衡以工序向有序站位分配为核心，目标依问题设定；调度涉及执行顺序、起止时刻及资源使用。本课题联合决定工序、站位和具体团队，未将调度限定为分站后的站内排序。 |",
    20: "| 20 | 确定2.1.2标题并衔接本节 | 标题改为“工序延迟开工下的重调度”；本节末段同步使用重调度，明确冻结范围、可调整工序及完工时间与计划改动的评价。一般动态调度文献仍作为引入，既定工作题名不改。 |",
})
assert len(rows) == 25 and 10 not in rows
rows[5] = rows[5].replace("第4项所涉及的整段生产过程改写仍待讨论。", "第4项的生产过程说明现已落实。")
table = "\n".join(lines[:2] + [rows[n] for n in sorted(rows)])
pending = previous[previous.index("### 10. "):previous.index("### 16. ")].strip()
pending = pending.replace("小节标题与第20项一起决定。", "小节标题现已按第20项确定，本节末段已写为重调度；其余相关表述继续核对。")
pending = pending.replace("45处是相关检查位置，不等于45处都要改。", "45处是上一轮的相关检查位置，不等于45处都要改；附录保留当时的原句，引用号不替代最新Word的编号。")
pending = pending.replace("本次只更新已确认定义、五站位来源和转站耗时。", "本次已经同步平衡、调度和重调度定义，并记录后移文献及2.1.2标题。")
appendix = previous[previous.index("## 附录："):]
confirmed = []
for heading, key in [
    ("1.4新增的研究价值文字", ""),
    ("1.2五站位与同步转站", "production_paragraphs"),
    ("1.2平衡与调度", "balance_and_scheduling_paragraph"),
    ("1.3工序后移的文献", "industrial_case_paragraph"),
    ("2.1.2标题与本节末段", "section212_summary"),
]:
    if not key:
        text = next(x[2:] for x in previous.splitlines() if x.startswith("> 具体而言"))
    else:
        text = manifest[key]
    if heading.startswith("2.1.2"):
        text = [manifest["section212_title"], text]
    if not isinstance(text, list):
        text = [text]
    confirmed.append("### " + heading + "\n\n" + "\n\n".join("> " + x for x in text))
new = "\n\n".join([
    "# 开题报告已确认修订与扰动口径待核对",
    "日期：2026年10月10日。",
    "修订基准为用户自行修改并添加26条批注的《开题报告_正式稿_20261009(2)(3).docx》。前一轮已落实19项；本次继续落实第3、4、7、16、17、20项，共25项。第10项涉及既有实验口径及跨文件同步，仍单独记录。",
    "## 一 已经落实的25项\n\n" + table,
    "原有26条批注全部保留。1.4原有两段与新增文字兼容，因此完整保留。正式正文按文献直接介绍工业案例和本课题约束，不加入案例与模型规则是否完全相同的说明。",
    "## 二 本次已经写入的文字\n\n" + "\n\n".join(confirmed),
    "新增文献：\n\n" + manifest["added_reference"],
    "## 三 第10项继续核对\n\n" + pending,
    "## 四 核查状态\n\n- 保留全部26条批注及其引用，13个原生数学对象逐个比较保持一致。\n- 新增参考文献为[9]，原[9]—[40]同步改为[10]—[41]；正文与参考文献表一并更新。\n- 保留工艺数据规模、36个既有场景、现有研究结果及投稿状态。\n- 1.4新增段落及其原有两段全部保留；五站位说明和重调度章节按本次确认修改。\n- 页面核查：等待本轮最终渲染检查。",
    appendix,
]) + "\n"
record = OUT / "开题报告_已确认修订与扰动口径待核对_20261010.md"
record.write_text(new)

terms = OUT / "开题报告_统一术语与当前定义_20261006.md"
s = terms.read_text()
s = s.replace("2026年10月10日补充已确认的工厂来源、转站耗时和扰动定义", "2026年10月10日补充工厂来源、转站耗时、扰动定义及本轮确认的平衡与调度说明")
s = s.replace(
    "| 装配线平衡 | 将任务分配到有序站位，优化周期、站位数量或负荷等目标 | 与精细时间调度绝对分离；把工时总和等同于本站完成时刻 |",
    "| 装配线平衡 | 将工序分配到有序站位，在工艺前序等约束下，根据问题设定优化站位数量、周期或相应负荷目标 | 各模型同时优化所有目标；与作业顺序、时间和资源安排绝对分离；把工时总和等同于本站完成时刻 |")
needle = "| 工序前序约束 |"
assert needle in s
s = s.replace(needle, "| 调度 | 确定工序的执行顺序、起止时刻及资源使用；本课题联合决定工序安排、执行站位与具体人员团队 | 仅指完成工序分站后的站内排序；等同于装配线平衡 | Vieira等，2003；Bao等，2023；Pucel与Roussel，2024 |\n" + needle, 1)
s = s.replace("| 重调度 | 开工条件变化后，在模型允许的范围内更新已有排程 |", "| 重调度 | 响应扰动或其他变化，在模型允许的范围内更新已有排程；工作二具体研究工序延迟开工后的修订 |")
source = "- Abdinnour S. Hawker Beechcraft Uses a New Solution Approach to Balance Assembly Lines. Interfaces, 2011, 41(2):164–176：[出版社摘要与出版信息](https://pubsonline.informs.org/doi/10.1287/inte.1100.0535)。用于介绍未完成作业随飞机转站后继续安排的工业情况；本课题后移仍按已有工艺、流向和资源约束检查。\n"
s = s.replace("文献定义、研究设计和实施记录分开使用。", source + "\n文献定义、研究设计和实施记录分开使用。")
a = s.index("本轮依照用户确认，已落实26项批注方案中的20项")
s = s[:a] + (
    "本轮依照用户确认，已落实26项批注方案中的25项，第10项继续核对。"
    "第3项在1.4末尾补入具体研究价值段落，原有两段保留；第4项改写五站位生产过程；"
    "第7与17项统一平衡、调度定义及其联合研究关系；第16项补入工序后移工业案例；"
    "第20项将2.1.2确定为“工序延迟开工下的重调度”，并衔接本节末段。"
    "总体仍按静态调度、动态调度和多架次协同动态调度递进，小节标题具体指已有排程的修订，"
    "不将重调度与动态调度定义为严格同义。当前正式Word保留全部26条批注。"
    "第10项中工作二与多架次研究的扰动表述、既有实验设置及相关旧稿的全面同步，尚未完成。\n")
terms.write_text(s)

evidence = (
    "# 本轮文字修订的来源核查\n\n日期：2026年10月10日。\n\n"
    "## 装配线平衡与调度\n\n"
    "Boysen、Schulze与Scholl（2022）的综述将装配线平衡的核心概括为站位之间的任务分配，"
    "并讨论前序约束及不同问题设定。正文按此解释工序分站，未把所有目标写成同时优化。\n\n"
    "来源：https://doi.org/10.1016/j.ejor.2021.11.043\n\n"
    "Vieira、Herrmann与Lin（2003）的作者公开全文§3.1定义排程、调度与重调度；"
    "排程说明资源上作业的起止时刻，重调度响应扰动或其他变化更新已有排程。"
    "本报告2.1.2据此聚焦工序延迟开工下的重调度，未改动既定工作题名。\n\n"
    "来源：https://isr.umd.edu/Labs/CIM/projects/jos-rescheduling.pdf\n\n"
    "Pucel与Roussel（2024）的原始出版记录及论文研究联合装配线平衡与调度，"
    "原文已有该引用，继续用于解释两者可以联合研究。\n\n"
    "来源：https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.CP.2024.23\n\n"
    "## 后移工业案例\n\n"
    "Abdinnour（2011）的INFORMS出版社摘要明确记录Hawker 800XP产线按预定时间转站、"
    "前一站位仍有未完成作业以及在原定站位之外完成作业的情况。正文仅概述这一生产事实，"
    "随后说明本课题有限后移须满足工艺前序、单向流动和人员条件，并不迫使其他工序新增换站。"
    "不把案例作为本模型全部规则的可行性证明，也不在正文增加无关的规则差异声明。"
    "本次使用出版社摘要和出版信息，未取得全文。\n\n"
    "文献信息：Abdinnour S. Hawker Beechcraft Uses a New Solution Approach to Balance Assembly Lines. "
    "Interfaces, 2011, 41(2):164–176. DOI:10.1287/inte.1100.0535.\n\n"
    "来源：https://pubsonline.informs.org/doi/10.1287/inte.1100.0535\n")
(OUT / "本轮文字修订_来源核查_20261010.md").write_text(evidence)
print(json.dumps({"record":str(record),"confirmed_items":25,"remaining_item":10},ensure_ascii=False))
