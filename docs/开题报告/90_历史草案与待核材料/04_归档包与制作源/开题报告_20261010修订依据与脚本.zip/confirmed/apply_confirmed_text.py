"""Apply the additional wording confirmed by the user on 2026-10-10.

Usage: primary-python apply_confirmed_text.py SOURCE.docx OUTPUT.docx
Run after add_section14.py. Preserve comments, native mathematics and all
package parts except document.xml; insert one verified reference and renumber.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import etree as E
import copy
import hashlib
import json
import re
import sys

SOURCE, DEST = map(Path, sys.argv[1:3])
ROOT = Path(__file__).resolve().parent
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W, "m": "http://schemas.openxmlformats.org/officeDocument/2006/math"}
q = lambda x: "{" + W + "}" + x
flat = lambda p: "".join(p.xpath(".//w:t/text()", namespaces=NS))
with ZipFile(SOURCE) as z:
    data = {n: z.read(n) for n in z.namelist()}
doc = E.fromstring(data["word/document.xml"])
body = doc.find(q("body"))
ps = body.findall(q("p"))
original_text = [flat(p) for p in doc.xpath("//w:body//w:p", namespaces=NS)]
original_math = [E.tostring(e) for e in doc.xpath("//m:oMath", namespaces=NS)]

def find(prefix):
    found = [p for p in ps if flat(p).startswith(prefix)]
    assert len(found) == 1, (prefix, len(found))
    return found[0]

def format_props(p):
    ppr = p.find(q("pPr"))
    return copy.deepcopy(ppr), copy.deepcopy(ppr.find(q("rPr")))

def comment_parts(p):
    marks = {}
    refs = {}
    for e in p.iter():
        if e.tag in [q("commentRangeStart"), q("commentRangeEnd")]:
            marks[(E.QName(e).localname, e.get(q("id")))] = copy.deepcopy(e)
        elif e.tag == q("commentReference"):
            refs[e.get(q("id"))] = copy.deepcopy(e.getparent())
    return marks, refs

def write_text(p, text, events=(), markers=None, references=None, props=None):
    """Rebuild only a text paragraph, with explicit surviving comment ranges."""
    assert not p.xpath(".//m:oMath|.//w:drawing|.//w:object", namespaces=NS)
    ppr, rpr = props if props is not None else format_props(p)
    for child in list(p):
        p.remove(child)
    if ppr is not None:
        p.append(copy.deepcopy(ppr))
    pos = 0
    for offset, kind, cid in sorted(events, key=lambda x: x[0]):
        assert pos <= offset <= len(text)
        if offset > pos:
            run = E.SubElement(p, q("r"))
            if rpr is not None:
                run.append(copy.deepcopy(rpr))
            t = E.SubElement(run, q("t"))
            t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
            t.text = text[pos:offset]
        if kind == "reference":
            p.append(copy.deepcopy(references[cid]))
        else:
            p.append(copy.deepcopy(markers[(kind, cid)]))
        pos = offset
    if pos < len(text):
        run = E.SubElement(p, q("r"))
        if rpr is not None:
            run.append(copy.deepcopy(rpr))
        t = E.SubElement(run, q("t"))
        t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
        t.text = text[pos:]

def plain_paragraph(text, template):
    p = E.Element(q("p"))
    write_text(p, text, props=format_props(template))
    return p

production = find("图1以三个站位示意")
production_original = flat(production)
props = format_props(production)
markers, references = comment_parts(production)
assert set(references) == {"3", "4"}
production1 = (
    "图1以三个站位示意飞机脉动装配线中的工序、飞机、站位与人员关系。"
    "本课题研究调研工厂的五站位脉动装配线。飞机从一号站位进入，"
    "沿产线依次向后续站位移动，最后从五号站位离线。不同站位可以同时装配不同飞机。"
)
production2 = (
    "在本课题模型中，相邻两次转站之间，飞机停留在本站进行装配。"
    "等各站飞机均完成当前安排在本站的作业后，全线统一转站："
    "五号站位的飞机离线，其余飞机各向前移动一个站位。"
    "若本批次还有待投产飞机，新飞机同时进入一号站位。"
    "两次实际转站之间的时间间隔称为实际生产周期。"
)
a = production1.index("本课题研究")
b = production1.index("。", a) + 1
write_text(production, production1,
           [(0, "commentRangeStart", "3"), (a, "commentRangeStart", "4"),
            (b, "commentRangeEnd", "4"), (b, "reference", "4")],
           markers, references)
continuation = E.Element(q("p"))
write_text(continuation, production2,
           [(len(production2), "commentRangeEnd", "3"),
            (len(production2), "reference", "3")],
           markers, references, props)
body.insert(body.index(production) + 1, continuation)

balance = find("装配线平衡主要处理")
balance_original = flat(balance)
markers, references = comment_parts(balance)
assert set(references) == {"6"}
balance_text = (
    "工序的站位分配需要与作业时间、人员安排一并考虑。即使各站承担的工作量相近，"
    "工艺前序关系和人员冲突仍可能使各站的完成时间不同。"
    "装配线平衡主要研究工序向有序站位的分配，根据问题设定，在工艺前序等约束下"
    "优化站位数量、周期或相应负荷目标[5]；调度确定工序的执行顺序、起止时刻及资源使用。"
    "飞机装配已有将两者联合求解的研究[6]。本课题联合确定工序安排、执行站位与具体人员团队，"
    "以具体排程和实际执行结果评价生产时间，并根据工艺前序及资源约束检查可行性。"
)
a = balance_text.index("装配线平衡主要研究")
b = a + len("装配线平衡主要研究工序向有序站位的分配")
write_text(balance, balance_text,
           [(a, "commentRangeStart", "6"), (b, "commentRangeEnd", "6"),
            (b, "reference", "6")], markers, references)

title = find("2.1.2 工序延迟开工与计划修复")
markers, references = comment_parts(title)
assert set(references) == {"19"}
title_text = "2.1.2 工序延迟开工下的重调度"
write_text(title, title_text,
           [(6, "commentRangeStart", "19"), (len(title_text), "commentRangeEnd", "19"),
            (len(title_text), "reference", "19")], markers, references)

summary = find("对于本课题，动态研究需要明确")
summary_original = flat(summary)
assert not comment_parts(summary)[1]
summary_text = (
    "对本课题，重调度需要明确冻结范围、人员站位绑定和可调整工序，"
    "在更新工序最早可开工时刻后修复排程。计划稳定性按相对于固定基准排程的"
    "开工时刻、执行站位和团队成员变化评价。研究问题由此从无扰动联合安排，"
    "扩展为工序延迟开工后兼顾完工时间与计划改动的重调度。"
)
write_text(summary, summary_text)

# Existing references 9--40 become 10--41. Apply to whole paragraph text,
# preserving run boundaries and comment markers even for split citations.
brackets = re.compile(r"\[(\d{1,2}(?:\s*[,，\-–—]\s*\d{1,2})*)\]")
def renumber(p):
    nodes = p.findall(".//" + q("t"))
    text = "".join(t.text or "" for t in nodes)
    starts = []
    pos = 0
    for node in nodes:
        end = pos + len(node.text or "")
        starts.append((node, pos, end))
        pos = end
    for m in reversed(list(brackets.finditer(text))):
        nums = [int(x) for x in re.findall(r"\d+", m.group(1))]
        assert all(1 <= x <= 40 for x in nums), (text, nums)
        if all(x < 9 for x in nums):
            continue
        value = re.sub(r"\d+", lambda z: str(int(z.group()) + (int(z.group()) >= 9)), m.group())
        inserted = False
        for node, lo, hi in starts:
            if hi <= m.start() or lo >= m.end():
                continue
            a, b = max(0, m.start() - lo), min(hi, m.end()) - lo
            node.text = (node.text or "")[:a] + (value if not inserted else "") + (node.text or "")[b:]
            inserted = True
        assert inserted
for p in doc.xpath("//w:body//w:p", namespaces=NS):
    renumber(p)

industrial_text = (
    "飞机装配中也存在未完成作业随飞机转站后继续安排的情况。"
    "Abdinnour以Hawker Beechcraft公司的Hawker 800XP装配线为例，介绍了飞机按预定时间转站、"
    "部分未完成作业在原定站位之外继续执行的生产安排[9]。"
    "本课题考虑有限工序后移，要求后移安排满足工艺前序、单向流动和人员约束，"
    "且不迫使其他工序新增换站。"
)
anchor = find("同步转站把不同飞机的局部进度联系起来")
industrial = plain_paragraph(industrial_text, anchor)
body.insert(body.index(anchor), industrial)
reference_template = find("[10] Boysen N, Fliedner M, Scholl A.")
reference_text = (
    "[9] Abdinnour S. Hawker Beechcraft Uses a New Solution Approach to Balance Assembly Lines[J]. "
    "Interfaces, 2011, 41(2):164–176. DOI: 10.1287/inte.1100.0535."
)
reference = plain_paragraph(reference_text, reference_template)
body.insert(body.index(reference_template), reference)

# Independent checks for review objects, equation bytes and reference mapping.
starts = doc.xpath("//w:commentRangeStart/@w:id", namespaces=NS)
ends = doc.xpath("//w:commentRangeEnd/@w:id", namespaces=NS)
refs = doc.xpath("//w:commentReference/@w:id", namespaces=NS)
assert len(starts) == len(set(starts)) == 26
assert sorted(starts) == sorted(ends) == sorted(refs)
assert [E.tostring(e) for e in doc.xpath("//m:oMath", namespaces=NS)] == original_math
final_text = [flat(p) for p in doc.xpath("//w:body//w:p", namespaces=NS)]
ref_lines = [t for t in final_text if re.match(r"^\[\d+\]\s", t)]
assert [int(re.match(r"^\[(\d+)\]", t).group(1)) for t in ref_lines] == list(range(1,42))
assert len(final_text) == len(original_text) + 3
for prefix in ["本课题从上述生产问题出发组织三项研究", "三项研究依次扩展关系信息", "具体而言，本课题比较共享图传播"]:
    before = next(t for t in original_text if t.startswith(prefix))
    assert next(t for t in final_text if t.startswith(prefix)) == before
assert title_text in final_text
assert not any(t.startswith("2.1.2 工序延迟开工与计划修复") for t in final_text)
assert all(word not in industrial_text for word in ["不足以", "不能严格", "完全一致", "可行性证明"])
data["word/document.xml"] = E.tostring(doc, encoding="UTF-8", xml_declaration=True, standalone=True)
with ZipFile(DEST, "w", ZIP_DEFLATED) as z:
    for name, content in data.items():
        z.writestr(name, content)
with ZipFile(SOURCE) as a, ZipFile(DEST) as b:
    assert all(a.read(n) == b.read(n) for n in a.namelist() if n != "word/document.xml")

manifest = {
    "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "output_sha256": hashlib.sha256(DEST.read_bytes()).hexdigest(),
    "newly_confirmed_items": [3,4,7,16,17,20],
    "remaining_pending_item": 10,
    "production_paragraphs": [production1,production2],
    "balance_and_scheduling_paragraph": balance_text,
    "industrial_case_paragraph": industrial_text,
    "section212_title": title_text,
    "section212_summary": summary_text,
    "added_reference": reference_text,
    "reference_count": 41,
    "reference_mapping": "Old 1--8 unchanged; new industrial case is 9; old 9--40 become 10--41",
    "native_math_objects_preserved": len(original_math),
    "comments_preserved": len(starts),
    "section14_all_three_paragraphs_preserved": True,
    "source_only_changes_in_document_xml": True,
}
(ROOT/"deliverables/confirmed_text_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps({"output":str(DEST),"comments":26,"references":41,"math_objects":13},ensure_ascii=False))
