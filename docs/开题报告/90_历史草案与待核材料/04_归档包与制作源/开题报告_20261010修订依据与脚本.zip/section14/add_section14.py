"""Append the confirmed concrete research-value paragraph to section 1.4.

Existing paragraph text and comments remain untouched. Only document.xml changes.
One redundant forced page break is removed after the addition to avoid a near-empty page.
"""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import etree as E
import copy
import hashlib
import json

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / "report_revision_20261010_1020"
OUT = ROOT / "deliverables"
SOURCE = BASE / "deliverables/开题报告_批注修订稿_20261010.docx"
DEST = OUT / SOURCE.name
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
NS = {"w": W, "m": "http://schemas.openxmlformats.org/officeDocument/2006/math"}
q = lambda local: "{" + W + "}" + local
TEXT = (
    "具体而言，本课题比较共享图传播与按关系类型组织信息对联合决策的影响，"
    "并研究生产时间预测如何帮助策略判断不同站位及相邻周期的作业安排。"
    "生产效果分别从无扰动排程的完工时间、受扰后排程调整的幅度，"
    "以及多架飞机连续装配中的等待和整批工期进行评价。"
    "通过对照和消融实验，说明各项设计在何种生产条件下能够发挥作用。"
)

with ZipFile(SOURCE) as z:
    data = {n: z.read(n) for n in z.namelist()}
doc = E.fromstring(data["word/document.xml"])
body = doc.find(q("body"))
flat_text = lambda p: "".join(p.xpath(".//w:t/text()", namespaces=NS))
ps = body.findall(q("p"))
start = next(i for i, p in enumerate(ps) if flat_text(p) == "1.4 选题依据与研究意义")
end = next(i for i in range(start + 1, len(ps)) if flat_text(ps[i]).startswith("2 "))
old = ps[start + 1:end]
assert len(old) == 2 and all(flat_text(p) for p in old)
assert not any(TEXT in flat_text(p) for p in ps)
preserved_paras = [E.tostring(p) for p in old]
new = E.Element(q("p"))
new.append(copy.deepcopy(old[-1].find(q("pPr"))))
run = E.SubElement(new, q("r"))
prototype = old[-1].find(".//" + q("rPr"))
if prototype is not None:
    run.append(copy.deepcopy(prototype))
E.SubElement(run, q("t")).text = TEXT
body.insert(body.index(ps[end]), new)
# The added paragraph shifts the end of section 5 onto the following page.
# Do not leave that short continuation alone before a forced section-6 break.
schedule = next(p for p in ps if flat_text(p) == "6 研究进度安排")
schedule_break = schedule.find("w:pPr/w:pageBreakBefore", namespaces=NS)
assert schedule_break is not None
schedule_break.getparent().remove(schedule_break)
assert [E.tostring(p) for p in old] == preserved_paras
assert len(doc.xpath("//m:oMath", namespaces=NS)) == 13
ids = doc.xpath("//w:commentRangeStart/@w:id", namespaces=NS)
assert len(ids) == len(set(ids)) == 26
for el in new.xpath(".//w:commentRangeStart|.//w:commentRangeEnd|.//w:commentReference", namespaces=NS):
    raise AssertionError("The new paragraph must not duplicate comment anchors")
data["word/document.xml"] = E.tostring(doc, encoding="UTF-8", xml_declaration=True, standalone=True)
with ZipFile(DEST, "w", ZIP_DEFLATED) as z:
    for name, content in data.items():
        z.writestr(name, content)
with ZipFile(SOURCE) as a, ZipFile(DEST) as b:
    unchanged = [n for n in a.namelist() if n != "word/document.xml"]
    assert all(a.read(n) == b.read(n) for n in unchanged)
    original = E.fromstring(a.read("word/document.xml"))
    original_paras = original.xpath("//w:body//w:p", namespaces=NS)
    final_paras = doc.xpath("//w:body//w:p", namespaces=NS)
    assert len(final_paras) == len(original_paras) + 1
    assert [flat_text(p) for p in final_paras if p is not new] == [flat_text(p) for p in original_paras]

manifest = {
    "scope": "Add the approved research-value paragraph to the end of section 1.4",
    "source_library_version": 1,
    "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "output_sha256": hashlib.sha256(DEST.read_bytes()).hexdigest(),
    "existing_section14_paragraphs_preserved": [flat_text(p) for p in old],
    "added_paragraph": TEXT,
    "native_math_objects_preserved": 13,
    "comments_preserved": 26,
    "unchanged_package_parts": len(unchanged),
    "pending_items": [4, 7, 10, 16, 17, 20],
    "pagination_adjustment": "Removed the forced page break before section 6 to avoid a near-empty continuation page after adding section 1.4; no existing text was changed",
}
(OUT / "section14_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2))

# Keep the decision record consistent with the newly confirmed proposal 3.
record_source = BASE / "deliverables/开题报告_已确认修订与七项待讨论_20261010.md"
s = record_source.read_text()
s = s.replace("# 开题报告：已确认修订与七项待讨论", "# 开题报告：已确认修订与六项待讨论")
s = s.replace("本轮只落实用户已经认可的19项方案；第3、4、7、10、16、17、20项仍为讨论稿，不把本文件中的候选文字写入Word。", "前一轮已落实19项方案；本次继续落实用户新确认的第3项，在1.4末尾补入具体研究价值段落，保留原有两段。第4、7、10、16、17、20项仍为讨论稿，其待确认文字不写入Word。")
s = s.replace("## 一、已经落实的19项", "## 一、已经落实的20项")
s = s.replace("| 5 | 明确五站位", "| 3 | 补充具体研究价值 | 在1.4末尾新增一段，明确图表示的比较对象、生产时间预测的用途，以及完工时间、计划改动、等待与整批工期等评价内容；原有两段保留。 |\n| 5 | 明确五站位")
s = s.replace("第3项的研究价值扩写、第4项的完整生产过程改写", "第3项的研究价值扩写已完成；第4项的完整生产过程改写")
s = s.replace("## 二、七项待讨论的建议", "## 二、六项待讨论与已确认的研究价值文字")
s = s.replace("### 3. 怎样补强具体研究价值", "### 3. 具体研究价值（已确认并补入1.4）")
s = s.replace("可用于1.4的候选文字：", "本次在1.4末尾补入的文字：")
candidate = "本课题围绕工序分站、人员使用和同步转站开展研究。在方法上，比较共享图传播与按关系类型组织信息对联合决策的影响，并研究生产时间预测如何帮助策略判断不同站位及相邻周期的作业安排。在生产应用上，分别评价无扰动排程的完工时间、受扰后排程调整的幅度，以及多架飞机连续装配中的等待和整批工期。通过对照和消融实验，说明各项设计在何种生产条件下能够发挥作用。"
assert "> " + candidate in s
s = s.replace("> " + candidate, "> " + TEXT)
s = s.replace("该段写研究对象、评价内容和验证办法，不提前承诺提高产能或缩短工期的幅度。", "为衔接原有段落，开头改为“具体而言”，不重复连续的“方法上／应用上”结构。该段保留用户确认的比较对象、生产评价和验证办法，不提前承诺提高产能或缩短工期的幅度。")
s = s.replace("第19、26、33、37段", "原修订稿第19、26、33、37段")
s = s.replace("涉及研究价值和生产介绍的段落只作其他已确认项所要求的局部术语／来源修订。", "研究价值段落本次补入；生产介绍仍只保留先前已确认的局部来源修订。")
s = s.replace("- 页面核查：完成30页渲染及逐页版面检查；独立公式和行内变量均完整显示。", "- 页面核查：补入1.4后重新渲染并核查30页。取消第6章前导致大块空白的强制分页；各章文字、表格和图示保留，独立公式和行内变量完整显示。")
record_dest = OUT / "开题报告_已确认修订与六项待讨论_20261010.md"
record_dest.write_text(s)

# Only the confirmation status changes in the term reference, not definitions.
terms_source = BASE / "deliverables/开题报告_统一术语与当前定义_20261006.md"
s = terms_source.read_text()
s = s.replace("只落实26项批注方案中的19项：1、2、5、6、8、9、11—15、18、19、21—26。第3、4、7、10、16、17、20项继续讨论。", "已落实26项批注方案中的20项：1、2、3、5、6、8、9、11—15、18、19、21—26。其中第3项本次确认后已在1.4末尾补入具体研究价值段落，原有两段保留。第4、7、10、16、17、20项继续讨论。")
(OUT / terms_source.name).write_text(s)
print(json.dumps({"output": str(DEST), "added_characters": len(TEXT), "existing_section14_paragraphs": len(old), "comments": len(ids)}, ensure_ascii=False))
