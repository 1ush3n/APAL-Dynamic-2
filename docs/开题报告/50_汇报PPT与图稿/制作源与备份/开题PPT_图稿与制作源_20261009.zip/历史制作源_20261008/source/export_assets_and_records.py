from pathlib import Path
import base64, io, json, re, shutil, zipfile, html, os
from fontTools import subset
from fontTools.ttLib import TTFont
import subprocess
from lxml import etree

ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'deliverables'
SOURCE=ROOT/'source/开题报告/00_总控与交付'
QA=ROOT/'qa'
CN_FONT=Path('/workspace/scratch/0dffb7d03718/opening_revision_20261008/qa/fonts/DroidSansFallback.ttf')
EN_FONT=Path('/usr/share/fonts/opentype/urw-base35/NimbusRoman-Regular.otf')
scene_data=json.loads((OUT/'三项研究概念图_可编辑图形源_20261008.json').read_text())
deck=json.loads((QA/'deck_content.json').read_text())

def encoded_font(path,characters):
    f=TTFont(path)
    opt=subset.Options();opt.name_IDs=['*'];opt.name_legacy=True;opt.name_languages=['*']
    sub=subset.Subsetter(options=opt);sub.populate(text=characters);sub.subset(f)
    buffer=io.BytesIO();f.save(buffer)
    return base64.b64encode(buffer.getvalue()).decode()

chars=''.join(e.get('t','') for d in scene_data for e in d['elements'])
font_cn=encoded_font(CN_FONT,chars)
font_en=encoded_font(EN_FONT,chars)
css=("@font-face{font-family:'DeckCN';src:url(data:font/ttf;base64,"+font_cn+") format('truetype');}"
     "@font-face{font-family:'DeckEN';src:url(data:font/otf;base64,"+font_en+") format('opentype');}"
     "text{font-family:'DeckCN','Droid Sans Fallback';fill:#000;}")

def svg_text(e):
    x=e['x']+e['w']/2;y=e['y']+e['h']/2
    lines=e['t'].split('\n');size=e['size'];step=size*1.22
    first_y=y-(len(lines)-1)*step/2+size*.33
    parts=[]
    for i,line in enumerate(lines):
        spans=[]
        for t in re.findall(r'[\x20-\x7e]+|[^\x20-\x7e]+',line):
            fam="DeckEN,Nimbus Roman" if re.fullmatch(r'[\x20-\x7e]+',t) else "DeckCN,Droid Sans Fallback"
            spans.append(f'<tspan font-family="{fam}">{html.escape(t)}</tspan>')
        parts.append(f'<text x="{x:g}" y="{first_y+i*step:g}" font-size="{size:g}" text-anchor="middle" font-weight="{700 if e.get("bold") else 400}">'+''.join(spans)+'</text>')
    return '\n'.join(parts)

names={1:'工作一_联合静态调度示意图_20261008',2:'工作二_异构动态调度示意图_20261008',3:'工作三_多架次语义增强协同示意图_20261008'}
for sc in scene_data:
    items=[f'<svg xmlns="http://www.w3.org/2000/svg" width="680" height="475" viewBox="0 0 680 475"><defs><style>{css}</style><marker id="a" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 Z" fill="#000"/></marker></defs><rect width="680" height="475" fill="#fff"/>']
    for e in sc['elements']:
        if e['type']=='arrow':
            dash=' stroke-dasharray="9 6"' if e.get('dashed') else ''
            items.append(f'<line x1="{e["x1"]}" y1="{e["y1"]}" x2="{e["x2"]}" y2="{e["y2"]}" stroke="#000" stroke-width="2.5" marker-end="url(#a)"{dash}/>')
        else:
            if e['type']=='box':
                dash=' stroke-dasharray="9 6"' if e.get('dashed') else ''
                items.append(f'<rect x="{e["x"]}" y="{e["y"]}" width="{e["w"]}" height="{e["h"]}" fill="#fff" stroke="#000" stroke-width="2"{dash}/>')
            items.append(svg_text(e))
    items.append('</svg>')
    svg=OUT/(names[sc['kind']]+'.svg');svg.write_text('\n'.join(items))
    js="import {createRequire} from 'node:module';const require=createRequire(import.meta.url);const sharp=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/sharp');await sharp(process.argv[1]).resize(1360,950).png().toFile(process.argv[2]);"
    subprocess.run([os.environ['CODEX_PRIMARY_RUNTIME_NODE'],'--input-type=module','-e',js,str(svg),str(svg.with_suffix('.png'))],check=True)

PPT=OUT/'开题报告_汇报PPT_v1_20261008.pptx'
PDF=OUT/'开题报告_汇报PPT_v1_20261008.pdf'
def link(p):return f'[{p.name}](sandbox:{p})'
NS={'a':'http://schemas.openxmlformats.org/drawingml/2006/main'}
slide_text={}
with zipfile.ZipFile(PPT if PPT.exists() else ROOT/'build/candidate.pptx') as z:
    for r in deck['records']:
        xml=etree.fromstring(z.read(f'ppt/slides/slide{r["number"]}.xml'))
        slide_text[r['number']]=[''.join(p.itertext()) for p in xml.findall('.//a:t',NS)]

script_name='01_组会开题PPT逐页脚本_v1_20260928.md'
old_script=(SOURCE/script_name).read_text()
history=old_script.split('## 3. 历史详细素材',1)[1]
script=['# 组会开题PPT逐页脚本\n',
        '> **2026年10月8日当前交付：**已按用户选择采用B3纵向递进布局，完成可编辑PPT。主讲16页，后附2页引用来源；技术路线为三项各一页加一页验证与基础，采用3＋1。三方向综述各有原生可编辑表格，另设一页小结。本文当前页序与成品一致；历史素材不覆盖当前研究定义与页序。\n',
        link(PPT)+'；'+link(PDF)+'。\n',
        '## 1. 当前五章与篇幅\n',
        '| 章节 | 页码 | 展示任务 |\n|---|---|---|\n| 研究背景 | 3—4 | 脉动生产及联合决策 |\n| 文献综述 | 5—8 | 三方向表格＋小结 |\n| 研究内容 | 9—10 | B3总览＋三项独立概念图 |\n| 技术路线 | 11—14 | 三项路线＋验证与已有基础 |\n| 工作计划 | 15 | 实施阶段、条件与成果 |\n\n封面、目录和结束分别为1、2、16页；17—18页为来源附录。正式限时尚未指定，计时试讲待开展。\n',
        '## 2. 逐页正文、讲述与出处\n']
for r in deck['records']:
    n=r['number'];script.append(f'### 第{n}页：{r["title"]}\n\n**页面任务：**{r["claim"]}\n\n**可见文字：**\n')
    for t in slide_text[n]:script.append(f'- {t}\n')
    script.append('\n**讲述稿：**'+r['notes']+'\n\n')
    if r['refs']:
        script.append('**文献出处：**\n')
        for v in r['refs']:script.append(f'- [{v}] {deck["bibliography"][str(v)]}\n')
        script.append('\n')
    else:script.append('**定义出处：**当前全文整合稿§3—7及研究定义确认稿；自绘图为研究示意。\n\n')
script.append('## 3. 制作及下一轮核查\n\n三张综述表及验证、计划表为原生表格；B3、三项概念图与技术路线均为原生图形和文本，可继续编辑。中文Droid Sans Fallback，英文／数字Nimbus Roman；研究图和版式采用黑白。新同构方案、工作二既有实验及工作三拟开展分别说明。\n\n下一步按实际投影与试讲反馈调整内容密度，核对正式限时及汇报人／导师信息；未填入未经提供的人名。正式工作一、二题名未改，此处页面标题均为研究介绍。\n\n## 4. 历史详细素材'+history)
(OUT/script_name).write_text(''.join(script))

task_name='开题PPT_样例结构核对与精简任务表_20261008.md'
task=(SOURCE/task_name).read_text()
task=task.replace('## 4. 任务表与状态','## 4. 历史任务状态（本次制作前）',1)
newtasks='''## 4. 当前任务状态

| 任务 | 本轮产出 | 状态 |
|---|---|---|
| P1 样例参考 | 沿用8份PPT及24张重点页的核对 | 完成 |
| P2 展示取舍 | 五章；综述3＋1，路线3＋1 | 已按本轮授权落实 |
| P3 逐页脚本 | 16页主讲＋2页来源，讲述与成品一致 | 完成 |
| P4 图表准备 | B3总览、三个概念图、三项路线、综述原生表格 | 完成 |
| P5 可编辑PPT | 18页PPT及PDF预览 | 完成，已逐页排版核查 |
| P6 试讲核查 | 实际投影、计时、问答与进一步删减 | 待开展 |

本轮只完成展示材料，不把文稿、PPT或图稿完成登记为代码或实验完成。正文图3仍保留此前版本；PPT总览已按选定B3重排，正式题名未改。

'''
task=task.replace('## 4. 历史任务状态（本次制作前）',newtasks+'## 5. 历史任务状态（本次制作前）',1).replace('## 5. 沿用的研究与文档状态','## 6. 沿用的研究与文档状态')
task=task.replace('## 1. 当前阅读入口','## 1. 当前阅读入口\n\n- 当前成品：'+link(PPT)+'；'+link(PDF)+'。\n- 当前逐页脚本：'+link(OUT/script_name)+'。',1)
task=task.replace('> **2026年10月8日最新展示要求：**','> **2026年10月8日本轮制作完成：**用户选定B3并授权开始PPT。已完成16页主讲及2页来源，新增三项独立概念图，表格和图形可编辑；当前状态见§4。\n\n> **2026年10月8日最新展示要求：**',1)
(OUT/task_name).write_text(task)

take_name='开题PPT_展示取舍与关系图备选_20261008.md'
take=(SOURCE/take_name).read_text()
start=take.index('## 4. 建议篇幅')
take=take[:start]+'''## 4. 本轮落实的篇幅

| 章节 | 页数 | 页码 |
|---|---:|---|
| 研究背景 | 2 | 3—4 |
| 文献综述 | 3＋1 | 5—8 |
| 研究内容 | 2 | 9—10 |
| 技术路线 | 3＋1 | 11—14 |
| 工作计划 | 1 | 15 |

主讲含封面、目录和结束共16页；另附2页引用来源。增加的路线页用于同时交代验证与已有基础，避免三项核心路线挤入大量实验说明，不再额外增页。正式限时与计时试讲尚待落实。

## 5. 当前交付与后续

'''+link(PPT)+'；'+link(PDF)+'；'+link(OUT/script_name)+'''。

B3总览已用于PPT并重排为宽屏原生可编辑图形。另补三个独立概念图，其文字和功能与具体路线图分别安排。综述三页沿用已核对文献，各放一张可编辑比较表，再用一页小结衔接研究。

本轮完成逐页视觉、文字、字体和结构检查；实际投影、计时试讲和问答准备待开展。原CAC异构基础、新同构方案待验证、工作二未投稿与已测场景、工作三部分代码和拟实验继续分开。正式工作一、二题名不改，页面介绍语不替换题名。正文图3仍为原版，后续若同步B3须同时检查Word与文字稿。
'''
take=take.replace('更新：2026年10月8日，','> **本轮确认与交付：**用户选择B3；完整可编辑PPT已制作。主讲16页＋2页来源；技术路线3＋1。以下保留备选来源便于查阅，当前采用B3。\n\n更新：2026年10月8日，',1)
take=take.replace('具体新图待用户选定，正文图3仍为此前已插入版本。','用户本轮已选择B3，并用于PPT；正文图3仍为此前已插入版本。')
(OUT/take_name).write_text(take)

status=('> **2026年10月8日本轮PPT交付：**用户选择B3并授权制作。已按五章完成可编辑PPT：背景2页、综述3＋1页、研究内容2页、技术路线3＋1页、计划1页；含封面、目录、结束共16页主讲，另附2页引用来源。补齐三个独立概念图；文献表、研究图与路线图均为原生可编辑对象。已逐页核查排版、箭头、字体、引用和证据状态；实际投影、计时试讲与问答待开展。'+link(PPT)+'；'+link(PDF)+'；'+link(OUT/script_name)+'。工作一、二正式题名与研究定义不改，既有异构基础、新同构待验证、工作二已测场景与未投稿状态、工作三拟开展继续分开；正文图3仍保持此前版本，PPT使用选定B3。下方有日期的制作前记录保留历史语境。\n\n')
for name in ['04_老师审阅要求与开题落实台账_20261003.md','00_开题报告总控文稿_论证大纲与复用索引_20260928.md']:
    old=(SOURCE/name).read_text();pos=old.index('\n')+1
    revised=old[:pos]+'\n'+status+old[pos:]
    if name.startswith('00_'):
        revised=revised.replace('约15分钟、14页的页面论点、原图来源、讲述和问答备用区；修改内容时先同步本总控。','当前16页主讲＋2页引用来源；成品与脚本一致，旧14页素材属于历史；修改内容时先同步本总控。')
    (OUT/name).write_text(revised)

readme='''# 开题PPT图稿与制作源

本包包含三个研究概念图（SVG／PNG）、B3原始图、逐页内容与讲述记录，以及生成PPT的JavaScript和图稿导出脚本。
PPT中的表格、示意图和技术路线均是原生可编辑对象，图稿不替换已确定的工作一、二正式题名。
中文为Droid Sans Fallback，英文／数字为Nimbus Roman；SVG内嵌所需字体子集。字体完整文件放在fonts目录，供继续编辑时使用。
JavaScript生成程序依赖@oai/artifact-tool及相应运行时；SVG导出依赖Python、fonttools和Node sharp。源文件保存的是可复核制作过程，不代表生产算法已实现或实验完成。
主讲16页，引用来源2页；实际投影、计时试讲待开展。
'''
(OUT/'制作源_README.md').write_text(readme)
zip_path=OUT/'开题PPT_图稿与制作源_20261008.zip'
with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
    for base in names.values():
        for ext in ['svg','png']:z.write(OUT/(base+'.'+ext),'概念图/'+base+'.'+ext)
    z.write(SOURCE/'三项研究关系_B3_纵向递进_20261008.svg','总览/三项研究关系_B3_纵向递进_20261008.svg')
    z.write(ROOT/'build/build_deck.mjs','source/build_deck.mjs')
    z.write(Path(__file__).resolve(),'source/export_assets_and_records.py')
    z.write(OUT/'三项研究概念图_可编辑图形源_20261008.json','source/三项研究概念图_可编辑图形源_20261008.json')
    z.write(QA/'deck_content.json','source/deck_content.json')
    z.write(SOURCE/'开题报告_全文整合稿_20261006.md','source/开题报告_全文整合稿_20261006.md')
    z.write(OUT/script_name,script_name)
    z.write(OUT/'制作源_README.md','README.md')
    z.write(CN_FONT,'fonts/DroidSansFallback.ttf')
    for font in ['NimbusRoman-Regular.otf','NimbusRoman-Bold.otf']:
        z.write(EN_FONT.parent/font,'fonts/'+font)
print(json.dumps({'diagrams':len(names),'main_pages':16,'appendix':2,'bundle':str(zip_path)},ensure_ascii=False))
