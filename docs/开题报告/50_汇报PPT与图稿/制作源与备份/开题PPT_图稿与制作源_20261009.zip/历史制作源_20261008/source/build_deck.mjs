import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { Presentation, PresentationFile } from '@oai/artifact-tool';

const ROOT=path.resolve(import.meta.dirname,'..');
const OUT=path.join(ROOT,'deliverables');
const QA=path.join(ROOT,'qa');
const SKILL='/root/.codex/skills/builtins/presentations';
const CN='Droid Sans Fallback', EN='Nimbus Roman';
const W=1280,H=720;
await fs.mkdir(OUT,{recursive:true});await fs.mkdir(path.join(QA,'render'),{recursive:true});
const manuscript=await fs.readFile(path.join(ROOT,'source/开题报告/00_总控与交付/开题报告_全文整合稿_20261006.md'),'utf8');
const bibliography=Object.fromEntries([...manuscript.matchAll(/^\[(\d+)\] (.+)$/gm)].map(m=>[m[1],m[2]]));
const p=Presentation.create({slideSize:{width:W,height:H}});
const records=[];let uid=0;const diagrams=[];

function runs(t,bold=false){return [...String(t).matchAll(/[\x20-\x7e]+|[^\x20-\x7e]+/g)].map(m=>({run:m[0],style:{typeface:/^[\x20-\x7e]+$/.test(m[0])?EN:CN,bold}}));}
function setText(sh,t,size=26,bold=false,align='left',vertical='middle'){
  sh.text.style={fontSize:size,bold,color:'#000000',alignment:align,verticalAlignment:vertical,wrap:'square',autoFit:'none',insets:0};
  sh.text=String(t).split('\n').map(line=>({runs:runs(line,bold)}));
  return sh;
}
function text(s,t,x,y,w,h,size=26,bold=false,align='left'){
  return setText(s.shapes.add({name:`text-${++uid}`,geometry:'textbox',position:{left:x,top:y,width:w,height:h},fill:'none',line:{fill:'none',width:0}}),t,size,bold,align);
}
function box(s,t,x,y,w,h,size=24,options={}){
  const sh=s.shapes.add({name:`box-${++uid}`,geometry:options.geometry||'rect',position:{left:x,top:y,width:w,height:h},fill:options.fill||'#ffffff',line:{fill:'#000000',width:options.weight||1.5,style:options.dashed?'dashed':'solid'}});
  if(t!==null)setText(sh,t,size,options.bold||false,options.align||'center');
  return sh;
}
function line(s,x1,y1,x2,y2,weight=1.5,dashed=false){
  return s.shapes.add({name:`line-${++uid}`,geometry:'line',position:{left:Math.min(x1,x2),top:Math.min(y1,y2),width:Math.abs(x2-x1),height:Math.abs(y2-y1)},line:{fill:'#000000',width:weight,style:dashed?'dashed':'solid'},fill:'none'});
}
function link(s,a,b,options={}){
  return s.shapes.connect(a,b,{kind:options.kind||'straight',fromSide:options.from||'right',toSide:options.to||'left',line:{fill:'#000000',width:1.7,style:options.dashed?'dashed':'solid'},tail:{type:'triangle',width:'sm',length:'sm'}});
}
function arrow(s,x1,y1,x2,y2,dashed=false){
  return s.shapes.add({name:`arrow-${++uid}`,geometry:'connector',kind:'straight',position:{left:x1,top:y1,width:x2-x1,height:y2-y1},line:{fill:'#000000',width:1.7,style:dashed?'dashed':'solid'},tail:{type:'triangle',width:'sm',length:'sm'}});
}
function rule(s,x,y,w,weight=1.4){line(s,x,y,x+w,y,weight);}
function footer(s,n,chapter){rule(s,52,673,1176,.7);text(s,chapter,54,679,1050,26,17);text(s,String(n).padStart(2,'0'),1170,678,56,27,18,false,'right');}
function add(title,chapter,claim,notes,refs=[]){
  const n=p.slides.items.length+1,s=p.slides.add();s.background.fill='#ffffff';
  if(n>2&&n!==16){text(s,title,52,27,1176,57,38,true);rule(s,52,94,1176,2);footer(s,n,chapter);}
  const citations=refs.map(n=>`[${n}] ${bibliography[n]||'见研究资料原文。'}`).join('\n');
  s.speakerNotes.text=`页面任务：${claim}\n\n讲述稿：\n${notes}\n\n依据：当前全文整合稿及10月6日统一研究定义；图形为研究示意，不是实验轨迹。\n${citations}`;
  records.push({number:n,title,chapter,claim,notes,refs});return s;
}
function table(s,values,x,y,width,height,colWidths,size=23){
  const t=s.tables.add({rows:values.length,columns:values[0].length,left:x,top:y,width,height,columnWidths:colWidths,values:values.map((row,r)=>row.map(v=>String(v).split('\n').map(l=>({runs:runs(l,r===0)}))))});
  t.styleOptions={headerRow:true,bandedRows:false,bandedColumns:false};
  t.borders.assign({fill:'#000000',width:1,style:'solid'});
  t.cells.block({row:0,column:0,rowCount:values.length,columnCount:values[0].length}).assign({fill:'#ffffff',textStyle:{typeface:CN,fontSize:size,color:'#000000'},margins:{left:12,right:12,top:9,bottom:9},anchor:'center'});
  t.rows[0].height=50;
  t.cells.block({row:0,column:0,rowCount:1,columnCount:values[0].length}).assign({fill:'#eeeeee',textStyle:{bold:true,fontSize:size+1}});
  return t;
}
function takeaway(s,t,y=607){rule(s,58,y-12,1164,1);text(s,t,65,y,1150,48,25,true);}
function labelLines(s,items,x,y,width=1100,step=68,size=27){items.forEach((a,i)=>{text(s,a,x,y+i*step,width,55,size);});}
function stations(s,x,y,width,{small=false,progress=false}={}){
  const gap=17,bw=(width-gap*4)/5,bs=[];
  for(let i=0;i<5;i++){
    const a=box(s,`站位${i+1}`,x+i*(bw+gap),y,bw,small?40:52,small?18:25,{bold:true});
    const b=box(s,`飞机${5-i}`,x+i*(bw+gap),y+(small?54:68),bw,small?57:100,small?18:26);
    if(progress)text(s,i===2?'仍有任务':'完成后等待',x+i*(bw+gap),y+(small?116:176),bw,small?33:40,small?16:22,false,'center');
    if(i>0)link(s,bs[i-1],b);bs.push(b);
  }
  return bs;
}

// The three concept diagrams use shared vector primitives. They are editable in
// the PPTX and are also exported as SVG/PNG assets by the companion exporter.
function scene(kind){
  const e=[];
  const T=(t,x,y,w,h,size=25,bold=false)=>e.push({type:'text',t,x,y,w,h,size,bold});
  const B=(t,x,y,w,h,size=25,dashed=false)=>e.push({type:'box',t,x,y,w,h,size,dashed});
  const A=(x1,y1,x2,y2,dashed=false)=>e.push({type:'arrow',x1,y1,x2,y2,dashed});
  if(kind===1){
    T('无扰动：三项选择联合安排',20,8,620,48,36,true);
    B('工艺前序',35,82,175,60,34);B('人员条件',250,82,175,60,34);B('站位约束',465,82,175,60,34);
    A(123,142,123,187);A(338,142,338,187);A(552,142,552,187);
    B('选工序',35,187,175,68,38);B('选站位',250,187,175,68,38);B('选团队',465,187,175,68,38);
    A(210,221,250,221);A(425,221,465,221);
    T('三项选择共同决定起止安排',30,285,615,54,34);
    B('可行排程\n工序＋站位＋团队＋起止时刻',35,354,605,88,33);
  }else if(kind===2){
    T('受扰后：区分关系并修复计划',20,8,620,48,36,true);
    B('工序',35,82,130,54,36);B('站位',205,82,130,54,36);B('人员',375,82,130,54,36);B('技能',545,82,95,54,36);
    A(165,109,205,109);A(335,109,375,109);A(505,109,545,109);
    T('分别表示前序、归属与资格等关系',34,151,610,45,32);
    B('保留冻结安排',35,227,266,63,34);B('修复可调任务',351,227,289,63,34);
    T('继承站位绑定',35,304,266,45,32);T('工序、站位与团队',351,304,289,45,30);
    A(168,349,168,380);A(495,349,495,380);
    B('完工时间＋计划改动',35,380,605,57,36);
  }else{
    T('多架次：本次脉动与下一周期',20,8,620,48,36,true);
    const w=101,g=25;
    for(let i=0;i<5;i++){B(`站位${i+1}`,34+i*(w+g),90,w,42,28);B(`飞机${5-i}`,34+i*(w+g),148,w,57,28);if(i<4)A(135+i*(w+g),176,160+i*(w+g),176);}
    T('各飞机进度共同决定转站时刻',34,223,610,49,34);
    B('当前各站进度',34,305,269,62,34);B('下一周期任务',368,305,270,62,34);
    A(303,336,368,336,true);
    B('语义增强协同安排\n共同脉动＋后续负荷',34,387,605,80,34);
  }
  return {kind,width:680,height:475,elements:e};
}
function paintScene(s,sc,x,y,w,h){
  const k=Math.min(w/sc.width,h/sc.height);
  for(const e of sc.elements){
    if(e.type==='text')text(s,e.t,x+e.x*k,y+e.y*k,e.w*k,e.h*k,e.size*k,e.bold);
    else if(e.type==='box')box(s,e.t,x+e.x*k,y+e.y*k,e.w*k,e.h*k,e.size*k,{dashed:e.dashed});
    else arrow(s,x+e.x1*k,y+e.y1*k,x+e.x2*k,y+e.y2*k,e.dashed);
  }
}

// 1 Cover
{
 const s=add('基于图表示学习与强化学习的飞机脉动装配线调度方法研究','封面','交代课题与汇报类型','本课题研究飞机脉动装配线中的工序、站位和人员联合安排，围绕同构图静态调度、异构图动态调度与语义增强的多架次协同调度逐步展开。');
 text(s,'硕士学位论文开题报告',70,78,1100,55,28);rule(s,70,147,1140,2);
 text(s,'基于图表示学习与强化学习的\n飞机脉动装配线调度方法研究',70,204,1120,176,48,true);
 text(s,'控制科学与工程',74,491,1080,42,27);text(s,'2026年10月',74,543,1080,42,27);rule(s,70,640,1140,1);
}
// 2 Agenda
{
 const s=add('汇报内容','目录','明确五章结构','汇报依次介绍生产背景、三方面相关文献、研究内容、三项技术路线及验证安排，最后介绍工作计划。');
 text(s,'汇报内容',66,47,1100,67,46,true);rule(s,66,130,1145,2);
 ['研究背景','文献综述','研究内容','技术路线','工作计划'].forEach((t,i)=>{text(s,`0${i+1}`,78,182+i*84,110,55,31);text(s,t,203,182+i*84,975,55,32,true);rule(s,203,245+i*84,976,.7);});
}
// 3 Physical production
{
 const s=add('研究背景：飞机脉动装配线怎样生产','研究背景','说明驻站作业与同步脉动','飞机脉动装配线在驻站期间完成装配作业，再按站位顺序共同转站。不同飞机同时位于不同站位。本研究采用五站顺序流动；各在制站位都完成本站当前有效任务后，才发生本次实际脉动。这里的五站是研究设置，不是所有脉动线的固定数量。脉动与连续移动生产不能混为一谈。',[4,6]);
 text(s,'飞机驻站作业 → 各站完成当前任务 → 全线共同转站',60,111,1160,53,29,true);
 stations(s,65,188,1150,{progress:true});
 rule(s,67,440,1147,1.1);
 const b=box(s,'实际共同脉动',825,476,355,74,28,{bold:true});
 text(s,'各站任务完成时间不同',76,467,625,45,28);
 text(s,'本次转站取各在制站位最晚就绪时刻',76,523,685,46,26);
 arrow(s,730,514,816,514);
 takeaway(s,'局部工序延迟可能影响共同转站，但不能直接等同于整线延迟。');
 text(s,'生产组织示意；五站为本研究设置。依据：方水良等[4]、Bao等[6]。',63,649,1150,21,16);
}
// 4 Decisions
{
 const s=add('研究背景：需要联合决定什么','研究背景','明确生产决策和研究递进所面对的问题','工序选择决定先安排哪些任务；站位选择决定任务在哪一站执行；团队选择决定由哪些合格人员完成及其资源占用。三项选择共同影响起止安排。工艺前序、需求人数、资格、占用和单向站位流动都需满足。无扰动联合安排是起点，延迟开工需要调整允许修改的计划；连续多架次则需关注共同脉动和下一周期影响。',[6,10,13]);
 const xs=[65,467,869],labels=['选工序','选站位','选团队'];
 const bs=xs.map((x,i)=>box(s,labels[i],x,145,345,75,32,{bold:true}));link(s,bs[0],bs[1]);link(s,bs[1],bs[2]);
 ['先安排哪个任务？','在哪个站位执行？','由哪些合格人员执行？'].forEach((t,i)=>text(s,t,xs[i],232,345,48,26,false,'center'));
 text(s,'共同满足：工艺前序、人数与资格、人员占用、站位单向流动',68,312,1140,54,28,true);
 table(s,[['生产范围','新增困难'],['无外部扰动','工序、站位与团队相互影响'],['工序延迟开工','保留既有执行约束，同时兼顾时间与计划改动'],['多架次实际执行','当前任务安排可能改变共同脉动及下一周期任务']],64,388,1152,208,[250,902],24);
 text(s,'目标：在给定工艺与人员条件下，生成并执行合法安排。',68,617,1145,43,27,true);
}
// 5 Lit production
{
 const s=add('文献综述一：装配线平衡与飞机脉动线调度','文献综述','分清平衡、调度、受扰修复与多架次执行','装配线平衡通常关注任务分配和站位负荷；飞机总装还需要任务执行顺序、人员分配与作业时间安排。相关文献已经研究平衡与调度结合、相邻飞机实例以及受扰计划修复，因此不能说现有研究都只考虑单架飞机。本课题在这些基础上聚焦给定工艺与人员条件下，实际共同脉动及后续周期的协调。',[5,6,7,10,13]);
 text(s,'比较生产问题与决策范围，避免把不同问题当作同一种调度。',62,112,1156,44,26);
 table(s,[['代表文献','研究对象与决策','与本课题的联系／边界'],['Boysen等（2022）[5]','装配线平衡综述；任务分站与负荷','提供平衡概念；不等同于完整执行排程'],['Bao等（2023）[6]','飞机总装：分站、资源与并行任务安排','支撑平衡与调度结合；原文另含工具资源'],['Pucel等（2024）[7]','平衡＋调度；行走工人、并行站位','涉及相邻飞机；人员流动与本站位规则不同'],['Lovato等（2023）[13]','飞机装配受扰修复；保留既定安排','支撑冻结与计划稳定性；不替代实际批次执行'],['Zheng等（2025）[10]','生产调度＋人员分配；站位专属人员','工序站位已给定；本课题还含站位选择']],60,170,1160,417,[270,445,445],23);
 takeaway(s,'研究需要：结合工序、站位与人员安排，进一步跟踪受扰多架次的实际执行。');
}
// 6 Lit algorithms
{
 const s=add('文献综述二：装配调度的求解方法','文献综述','比较方法用途，明确图强化学习的研究空间','规则可快速选择任务，但效果依赖规则和实例；搜索及数学优化能明确处理目标与约束，但在动态反复求解时需要评估计算预算。强化学习可学习选择策略，图表示支持工艺依赖与资源联系，但不能直接照搬车间模型。表中Q学习引导遗传搜索与直接学习调度动作区分开，不把二者混称。具体算法是否更好需要统一生产条件和预算后比较。',[6,7,13,16,19,21,22,23,24]);
 table(s,[['方法类别及文献','主要用途','本课题需关注的条件'],['规则／启发式\nPanwalkar等[16]','按预设优先级选择任务','快速响应；规则需适配工艺与人员约束'],['元启发式\nBao等[6]、Wen等[19]','优先级搜索、局部搜索或遗传搜索','搜索预算与受扰后重复求解成本'],['数学优化／约束规划\nPucel[7]／Lovato[13]','显式建模分站、时间与冻结安排','约束表达清楚；规模与时限需实测'],['图强化学习\nZhang[21]／Wen[22]','学习工序选择；表示前序和资源状态','车间／单站动作不能直接覆盖全线联合决策'],['多智能体图强化学习\nChen等[23]','多站动态调度；选择等待或派工规则','已有多站协调；固定人员与规则动作不同']],60,134,1160,447,[282,428,450],23);
 takeaway(s,'研究需要：用图状态表示支持联合选择，并在相同信息与预算下验证响应表现。');
 text(s,'综述参考：Waubert de Puiseau等（2026）[24]。',63,649,1150,21,16);
}
// 7 Lit graph
{
 const s=add('文献综述三：图强化学习与动态状态表示','文献综述','引出关系区分与具体生产后果信息','图强化学习不只有单一种图。作业车间异构图研究已区分工序和机器，近邻研究也已有多站协调、知识图谱更新及时间属性。本课题的增量应具体限定为飞机脉动线中的工序、站位、人员、技能关系，以及多架次实际共同脉动与紧邻下一周期的时间后果，不能说前人都没有动态或时间信息。知识图谱的查询推理也不自动等于图神经网络编码。',[23,27,29,33,34]);
 table(s,[['代表文献','状态表示及决策','对本研究的启示／区别'],['Smit等（2025）[27]','作业车间图神经网络综述','图结构、特征及动作须匹配具体生产问题'],['Song等（2023）[29]','工序—机器异构图；复合动作','类型化关系有参考价值；未含飞机站位团队'],['Chen等（2026）[23]','多站图注意力与协调评价','已有跨站信息；需区分规则选择与联合动作'],['Ding等（2025）[33]','动态知识图谱推理；实时调度','语义更新有依据；任务为航空产品加工'],['Hu等（2025）[34]','语义图建模；双资源动态车间','已有时间属性；本研究预测共同脉动及下一周期']],60,139,1160,446,[270,450,440],23);
 takeaway(s,'研究需要：从区分不同关系，进一步理解多架次状态对整线与后续周期的影响。');
}
// 8 Summary
{
 const s=add('文献综述小结：研究问题与方法逐步递进','文献综述','把文献支撑的问题对应到三项研究，不堆砌算法名','三个研究共享工艺与人员约束以及联合动作基础。研究一先处理无外部扰动下的联合安排；研究二进一步区分工艺与资源关系，同时响应延迟开工；研究三进一步跟踪实际多架次，将局部状态连接到共同脉动和后续周期。递进来自生产问题与信息需求的扩展，不是把工作一输出当成工作二输入的串联。',[5,6,13,27,34]);
 table(s,[['需要回答的问题','研究回应','方法递进'],['三项选择相互影响，怎样形成可行安排？','研究一：无扰动联合静态调度','同构图统一表示'],['关系不同且开工受扰，怎样调整允许修改的计划？','研究二：异构联合调度＋考虑计划稳定性的重调度','区分实体与关系'],['多架次进度不同，怎样协调共同脉动及下一周期？','研究三：语义增强的多架次协同动态调度','分层融合＋时间后果信息']],63,150,1155,379,[442,427,286],26);
 text(s,'生产范围：无扰动安排 → 延迟开工后的调整 → 多架次实际执行',73,568,1130,43,28,true);
 text(s,'共同基础：工艺与人员条件、工序—站位—团队联合决策、可行性检查',73,622,1130,39,24);
}
// 9 B3 selected overview, reflowed to widescreen with editable objects.
{
 const s=add('研究内容：三项研究及其递进关系','研究内容','采用B3纵向排列，展示问题—内容—目标对应','采用已经选定的B3组织方式。第一项建立无扰动条件下的联合安排；第二项由关系利用及扰动响应需要引出；第三项由在制飞机实际状态和共同脉动带来的时间联系引出。图中文字是研究介绍，不替换已确定的工作一、二正式题名。共同基础保持工艺、人员约束与联合决策。');
 text(s,'研究问题',63,102,236,32,22,true,'center');text(s,'核心研究内容',306,102,699,32,22,true,'center');text(s,'关注目标',1034,102,180,32,22,true,'center');
 const ys=[142,314,486];
 for(const y of ys){box(s,null,59,y,1160,136,24,{dashed:true,fill:'none'});line(s,295,y,295,y+136,1);line(s,1020,y,1020,y+136,1);}
 text(s,'研究一\n工序、站位与团队\n怎样联合安排？',73,153,207,113,21,true);
 const h1=box(s,'同构图统一表示\n共享图传播规则',316,171,230,71,22),h2=box(s,'选工序',586,185,117,48,22),h3=box(s,'选站位',731,185,117,48,22),h4=box(s,'选团队',877,185,117,48,22);link(s,h1,h2);link(s,h2,h3);link(s,h3,h4);
 text(s,'排程质量\n可行性\n推理成本',1043,151,166,117,22);
 text(s,'一到二：进一步区分关系，并响应工序延迟开工',315,280,885,33,22,true);arrow(s,176,280,176,310);
 text(s,'研究二\n受扰后，怎样兼顾\n效率与计划稳定性？',73,325,207,113,21,true);
 const g1=box(s,'异构图关系表示\n前序、技能与安排',316,344,230,73,22),g2=box(s,'保留冻结安排',590,329,225,45,22),g3=box(s,'修复可调任务',590,390,225,45,22),g4=box(s,'合法调整计划',858,354,137,61,21);link(s,g1,g2);link(s,g1,g3);link(s,g2,g4);link(s,g3,g4);
 text(s,'完工效率\n计划稳定性',1043,331,166,107,22);
 text(s,'二到三：进一步跟踪多架次实际状态与共同脉动',315,451,885,34,22,true);arrow(s,176,451,176,483);
 text(s,'研究三\n多架次进度不同，怎样\n协调转站与后续周期？',73,497,207,113,20,true);
 const r1=box(s,'工序／飞机',315,499,192,41,20),r2=box(s,'站位',537,499,162,41,20),r3=box(s,'整线',729,499,162,41,20);link(s,r1,r2);link(s,r2,r3);
 const r4=box(s,'实际进度与最近变化',315,567,246,40,20),r5=box(s,'当前及下一周期后果',591,567,300,40,20),r6=box(s,'语义增强\n协同安排',911,517,91,71,20);link(s,r4,r5);link(s,r3,r6);link(s,r5,r6);
 text(s,'整批工期\n周期等待\n计划偏离',1043,493,166,117,22);
 text(s,'共同基础：工艺与人员约束、工序—站位—团队联合决策、可行性检查',68,631,1140,35,21,true,'center');
}
// 10 Three distinct concept figures.
{
 const s=add('研究内容：三个工作分别做什么','研究内容','提供每项研究的独立概念图，不提前展开实现','研究一在无扰动下共同安排工序、站位与团队；研究二显式区分工序、站位、人员、技能关系，受扰后保留冻结安排并修复可调任务；研究三跟踪各架飞机实际进度，以语义增强表示当前与下一周期联系，支持协同安排。下一章再说明网络、决策和反馈怎样连接。');
 const xs=[53,457,861],titles=['研究一：联合静态调度','研究二：异构动态调度','研究三：多架次协同'];
 for(let i=0;i<3;i++){
   text(s,titles[i],xs[i],118,366,42,27,true);
   const sc=scene(i+1);diagrams.push(sc);paintScene(s,sc,xs[i],184,367,330);
   const desc=[['同构图统一组织信息','输出：合法起止安排'],['异构图区分不同关系','输出：兼顾时间与改动的修复计划'],['融合各飞机、站位与整线信息','输出：当前与后续周期的协同决策']][i];
   text(s,desc.join('\n'),xs[i]+5,512,365,114,24);
   if(i<2)line(s,xs[i]+387,122,xs[i]+387,638,.7);
 }
}
// 11 Work 1 route
{
 const s=add('技术路线一：同构图下的联合静态调度','技术路线','说明共享传播与条件联合选择，明确新版本待验证','将工序、站位和人员信息组织在同一图中，采用共享传播规则生成表示。联合策略依次选择工序、站位与具体团队，后续选择以前面结果为条件。掩码与时间分配检查工艺前序、资格、人数、绑定和占用，形成起止安排。每次提交后更新安排状态，直到全部工序完成。新同构方案只对必要编码和接口适配，其他联合机制与训练基础保持；原CAC异构结果只作基础，不能作为新同构结果。',[36,37]);
 const a=box(s,'工艺＋人员条件\n可见完整工序图',66,151,238,86,27),b=box(s,'同构图编码\n共享传播规则',353,151,238,86,27),c=box(s,'条件联合选择\n工序 → 站位 → 团队',641,151,285,86,26),d=box(s,'合法时间分配\n起止安排',984,151,232,86,27);link(s,a,b);link(s,b,c);link(s,c,d);
 const e=box(s,'更新安排与人员占用，继续构造排程',351,281,578,59,26);link(s,d,e,{from:'bottom',to:'right',kind:'elbow'});link(s,e,b,{from:'left',to:'bottom',kind:'elbow'});
 labelLines(s,['图表示：保留输入信息，改变为单一图上的共享传播。','联合决策：后续选择以前面的工序、站位和团队成员为条件。','约束落实：动作掩码限制候选，时间分配检查前序与资源日历。'],72,380,1140,60,26);
 text(s,'训练：依据排程代价，以PPO更新联合策略。',72,563,1139,40,24);
 takeaway(s,'验证重点：完整可行性、排程质量与推理成本；新同构版本需独立训练和测试。');
}
// 12 Work 2 route
{
 const s=add('技术路线二：异构联合调度与计划稳定性','技术路线','展示两个组成部分和受扰修复边界','上层区分工序、站位、人员、技能及前序、需求、资格、归属和安排关系，为联合策略提供表示。受扰后更新已揭示开工条件，以原论文定义确定冻结与可调整范围，继承冻结条目和基准已使用人员站位绑定，只修复允许修改的安排。评价同时报告修复计划时间与开工、站位、团队偏离。这里基准计划是工作二内部的既有参照，不用来解释工作一到工作二的研究递进。当前未投稿稿已有初始调度、结构变体与36个固定物料延迟场景，结论按原设置解释，不预先宣布新独立消融。',[13,14]);
 const a=box(s,'工序／站位／人员／技能\n前序、需求、资格与归属',63,140,393,100,25),b=box(s,'异构图编码\n按关系组织传播',505,140,299,100,28),c=box(s,'工序—站位—团队\n联合决策',854,140,359,100,28);link(s,a,b);link(s,b,c);
 text(s,'延迟开工后，按原模型划分修复范围',64,265,1150,42,27,true);
 const d=box(s,'已揭示的开工条件\n已有计划与冻结边界',64,329,275,88,25),e=box(s,'保留冻结安排\n继承人员站位绑定',399,315,289,99,25),f=box(s,'调整允许修改的任务\n重新确定合法起止时刻',748,315,465,99,27);link(s,d,e);link(s,e,f);
 const g=box(s,'修复结果：完工时间＋开工／站位／团队偏离',400,465,813,69,28,{bold:true});link(s,f,g,{from:'bottom',to:'top',kind:'elbow'});
 text(s,'计划稳定性：衡量修复安排相对原计划的改动程度。',68,557,1135,45,27);
 takeaway(s,'已有证据：当前未投稿稿的初始调度、结构变体与36个固定物料延迟场景。');
}
// 13 Work 3 route
{
 const s=add('技术路线三：语义增强的多架次协同动态调度','技术路线','用简单输入输出解释语义位于动作前，事件与学习不同','每次完整决策前读取最新实际状态与最近变化。已有图编码保留完整工序上下文，未完成实际工序用于飞机和站位摘要，再融合到整线表示。语义模块在动作选择前提供当前共同脉动和紧邻下一周期各站就绪的时间后果信息，用于联合决策；输出是明确生产时间含义，不是新的泛化术语。预测跟随当前策略，真实事件发生后才形成监督，未知扰动不提前输入。实际事件更新受影响的生产事实，神经表示在每次完整决策前重算，参数在训练批次更新。预测副本按方案B保持整条采样轨迹的权重不变，但仍读取每次最新状态。完整实现和实验尚待完成。');
 const a=box(s,'多架次实际状态\n当前进度＋最近变化',60,144,266,84,26),b=box(s,'已有图编码\n保留完整工序上下文',376,144,288,84,26),c=box(s,'工序／飞机 → 站位 → 整线\n分层信息融合',712,144,507,84,27);link(s,a,b);link(s,b,c);
 const d=box(s,'语义信息\n本次共同脉动＋紧邻下一周期就绪',712,290,507,90,26,{bold:true}),e=box(s,'联合动作\n工序、站位与团队',375,290,287,90,27),f=box(s,'实际事件执行\n开工、完成\n扰动揭示、共同转站',60,290,266,90,24);link(s,c,d,{from:'bottom',to:'top'});link(s,d,e,{from:'left',to:'right'});link(s,e,f,{from:'left',to:'right'});link(s,f,a,{from:'top',to:'bottom'});
 text(s,'训练：实际结果回填时间标签；辅助预测学习与PPO策略学习配合。',65,423,1150,49,26);
 labelLines(s,['分层更新：事件维护生产事实；每次完整决策前重算网络表示。','决策用途：比较当前等待与下一周期任务负荷，支持多架次协同。'],69,493,1138,57,26);
 takeaway(s,'信息边界：扰动发生前不可预知；发生后才使用已揭示的持续时间。');
}
// 14 Validation and evidence, one useful supplemental route page.
{
 const s=add('验证安排：区分已有基础与拟开展实验','技术路线','单独交代证据状态、指标和验证，采用3+1路线组织','四个工艺规模为283、680、2338与3182道工序。工艺前序、标准工时及需求人数来自实际工厂；人员总量、资格和效率为实验设置。原CAC异构论文已有联合方法基础；新的同构方案待独立验证。工作二现稿已包含已有实验。工作三拟在相同数据、事件与预算下比较计划修复、站内调整、有限后移和完整语义方法，再分别消融分层、当前周期和下一周期模块。每项报告合法完成、生产分项和计算成本，未来实验不得写成已有性能优势。');
 text(s,'数据：四个工业工艺规模（283／680／2338／3182）；人员参数按实验设置。',63,112,1152,50,26);
 table(s,[['研究','已有基础／当前状态','主要验证内容'],['一','CAC原异构方法已形成；\n新同构方案拟独立实现、训练与测试','完整可行性、静态排程质量、推理成本；\n相同任务下比较图表示'],['二','未投稿稿已有初始调度、结构变体\n及36个固定物料延迟场景','修复时间、计划偏离、冻结与绑定一致性；\n必要时补充独立机制对照'],['三','方法设计已确认，部分代码已形成；\n完整实现与性能实验待完成','整批工期、周期超期、计划偏离、预测误差；\n分层、当前与下一周期消融']],60,180,1160,327,[80,510,570],24);
 text(s,'工作三主比较：计划修复 → 站内调整 → 有限后移 → 完整语义方法',66,537,1146,49,26,true);
 text(s,'统一工艺、人员条件、可见信息、测试事件与预算；可行性、质量和成本分开报告。',66,596,1144,65,25);
}
// 15 Plan
{
 const s=add('工作计划与预期成果','工作计划','按可核查的阶段成果推进，不虚构后续时间节点','近期优先完成开题材料和试讲，预计10月下旬开题。之后先完成同构接口及多架次环境核查，再跑通小规模训练、预测标签与PPO，固定实验协议，开展统一比较和机制验证，最后整合论文。各阶段可合理交错。租用AutoDL的4090服务器作为拟用计算条件；预计1至2篇论文和1篇会议论文，已有CAC录用成果单列，最终按实际进展核对，避免重复计数。');
 table(s,[['阶段','主要任务','阶段成果'],['近期：开题准备','正文、PPT与问答；计时试讲','汇报材料与来源记录'],['实现与环境核查','同构接口；多架次事件、前序、脉动与标签','可复核实现与完整合法轨迹'],['训练与验证','小训练、协议固定；正式比较与机制消融','生产指标、统计结果及计算成本'],['论文整合','完善工作二稿、形成工作三稿与学位论文','投稿材料与可复核实验记录']],60,134,1160,356,[230,535,395],25);
 text(s,'计算条件：拟租用AutoDL服务器，RTX 4090 GPU。',69,522,1135,49,27);
 text(s,'预期成果：1—2篇论文、1篇会议论文及硕士学位论文。',69,583,1135,49,28,true);
 text(s,'已有CAC 2026录用成果作为研究基础单列；后续发表状态按实际进展登记。',69,638,1135,30,21);
}
// 16 End
{
 const s=add('汇报结束','结束','进入问答','汇报结束，恳请各位老师批评指正。');
 // End page avoids duplicate header/footer from the normal content layout.
 text(s,'汇报结束',66,244,1148,82,56,true,'center');text(s,'恳请各位老师批评指正',66,352,1148,58,33,false,'center');rule(s,245,463,790,1.4);
}
// 17–18 References, shown after the end page and omitted from the main talk.
const used=[...new Set(records.flatMap(r=>r.refs))].sort((a,b)=>a-b);
const refGroups=[used.slice(0,Math.ceil(used.length/2)),used.slice(Math.ceil(used.length/2))];
for(let i=0;i<refGroups.length;i++){
 const s=add(`引用来源（${i+1}／2）`,'引用来源','完整来源供查阅，不增加主讲内容','参考文献编号沿用开题报告正文。这里只列本PPT使用的来源；更完整的综述及全文证据见正文与资料。',refGroups[i]);
 refGroups[i].forEach((n,j)=>{
   const original=bibliography[n];
   const short=n===36?original.replace('[EB/OL].',' · '):original.replace(/ DOI: .+$/,'').replace(/\[EB\/OL\].+/,'').replace(/\[C\]\/\//,' · ').replace(/\[J\]/,' · ');
   text(s,`[${n}] ${short}`,61,118+j*48.8,1157,47,20);
 });
}

await fs.writeFile(path.join(QA,'deck_content.json'),JSON.stringify({records,bibliography,used,mainSlideCount:16,totalSlideCount:p.slides.items.length},null,2));
await fs.writeFile(path.join(OUT,'三项研究概念图_可编辑图形源_20261008.json'),JSON.stringify(diagrams,null,2));
const candidate=path.join(ROOT,'build','candidate.pptx');
await (await PresentationFile.exportPptx(p)).save(candidate);
console.log(JSON.stringify({candidate,slides:p.slides.items.length,requiredNativeTables:[4,5,6,7,8,14,15]}));
for(let i=0;i<p.slides.items.length;i++){
 const s=p.slides.items[i];
 const b=await s.export({format:'png',scale:1.25});
 await fs.writeFile(path.join(QA,'render',`slide-${String(i+1).padStart(2,'0')}.png`),new Uint8Array(await b.arrayBuffer()));
 console.log(`rendered ${i+1}`);
}
await fs.writeFile(path.join(QA,'presentation.json'),await p.toProto?JSON.stringify(p.toProto()):'{}');
if(process.env.FINALIZE_DECK==='1'){
 const {finalizePresentation}=await import(pathToFileURL(path.join(SKILL,'container_tools/artifact_tool_utils.mjs')).href);
 const finalPath=path.join(OUT,process.env.DECK_OUTPUT_NAME||'开题报告_汇报PPT_20261008.pptx');
 const result=await finalizePresentation({workspaceDir:ROOT,candidatePath:candidate,finalPath,pythonExecutable:process.env.CODEX_PRIMARY_RUNTIME_PYTHON,integrityValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_package_integrity.py'),layoutValidatorPath:path.join(SKILL,'container_tools/inspect_presentation_layout_geometry.py'),layoutArgs:['--expected-slide-size-emu','12192000,6858000','--validate-bullet-geometry','--validate-heading-fit',...[4,5,6,7,8,14,15].flatMap(n=>['--require-native-table-slide',String(n)])],requiredNativeTableOwnerSlides:[4,5,6,7,8,14,15],requiredNativeChartOwnerSlides:[],fontPolicy:{basis:'design',families:[CN,EN]},verifyArtifactToolImport:true,receiptPath:path.join(QA,path.basename(finalPath)+'.validation.json')});
 console.log(JSON.stringify(result));
}
