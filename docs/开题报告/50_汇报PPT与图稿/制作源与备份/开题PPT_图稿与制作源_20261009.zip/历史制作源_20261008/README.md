# 开题PPT图稿与制作源

本包包含三个研究概念图（SVG／PNG）、B3原始图、逐页内容与讲述记录，以及生成PPT的JavaScript和图稿导出脚本。
PPT中的表格、示意图和技术路线均是原生可编辑对象，图稿不替换已确定的工作一、二正式题名。
中文为Droid Sans Fallback，英文／数字为Nimbus Roman；SVG内嵌所需字体子集。字体完整文件放在fonts目录，供继续编辑时使用。
JavaScript生成程序依赖@oai/artifact-tool及相应运行时；SVG导出依赖Python、fonttools和Node sharp。源文件保存的是可复核制作过程，不代表生产算法已实现或实验完成。
主讲16页，引用来源2页；实际投影、计时试讲待开展。
