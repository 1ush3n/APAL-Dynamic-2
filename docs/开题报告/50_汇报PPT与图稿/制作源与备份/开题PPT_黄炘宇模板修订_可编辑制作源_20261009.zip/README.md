# 黄炘宇模板修订制作源

本包记录2026年10月9日PPT修订的可编辑输入、制作代码和最终校验。

- author_native.mjs：Artifact Tool生成新关键问题页和右侧研究介绍等原生对象。
- assemble_native.py：将原生对象、用户所选技术图与黄炘宇实际模板组合，统一字体和备注。
- finalize.mjs：检查PPT结构、页数、字体、原生表格及Artifact Tool导入。
- sync_companions.py：同步逐页脚本、表述对照与总控状态。
- inputs：本轮输入的原主PPT与九页技术图候选。
- qa：字体预览说明、校验记录及来源清单。

黄炘宇完整模板已保存，按manifest中的文件名和身份取用，不在本包重复存放。代码里的工作目录及输入路径是本次制作环境路径；其他环境复用时需替换根路径、来源路径和Artifact Tool依赖路径。字体预览使用兼容字体，PPT实际指定SimHei与Times New Roman。代码不改生产模型或实验结果。
