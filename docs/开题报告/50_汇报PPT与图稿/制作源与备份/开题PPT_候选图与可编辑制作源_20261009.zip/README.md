# 开题PPT候选图与可编辑制作源

本包是独立候选预览，主PPT保持原样。两张合页及三个工作各三候选，共11页。

预览/中包含已核查的PPT、PDF、11张逐页PNG和三张纵向对比图；对比图从上到下依次A、B、C。说明/包含选取建议。build/为ArtifactTool JS可编辑作者源；fonts/为本轮沿用的中文、英文字体；source0/和source1/只保留源主PPT、引用内容和当前研究定义，便于追溯。

复现需现有Codex主运行时的@oai/artifact-tool与演示文稿技能工具；不包含node_modules。设置CODEX_PRIMARY_RUNTIME_NODE、CODEX_PRIMARY_RUNTIME_NODE_MODULES、CODEX_PRIMARY_RUNTIME_PYTHON，按演示技能建立build/node_modules软链接；为fonts建立fontconfig配置。执行build/build_preview.mjs时设置FONTCONFIG_FILE，使用新的PREVIEW_DRAFT_NAME和PREVIEW_FINAL_NAME，以保留既有导出结果。正常构建共11页；--merged-only只生成两张合页供检查。

此包保存候选展示和其制作源，不表示代码实验完成，不修改已确认正式题名。
