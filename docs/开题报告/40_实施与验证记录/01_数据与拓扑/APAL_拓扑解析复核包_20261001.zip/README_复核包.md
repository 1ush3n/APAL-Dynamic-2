本包不重复包含用户原始CSV。将原始文件置于同一输入目录，运行 python analyze_topology.py --input-dir 输入目录 --output-dir 结果目录。笔记本的INPUT_DIR可修改。对照loader构图需提供报告指定blob版本的data_loader.py。报告与summary记录本次对照结果；无loader时独立规则解析仍可运行。
