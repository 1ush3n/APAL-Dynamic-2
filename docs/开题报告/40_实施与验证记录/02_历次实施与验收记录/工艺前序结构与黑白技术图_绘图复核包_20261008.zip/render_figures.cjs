const fs = require('fs');
const path = require('path');
const sharp = require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'sharp'));
const base = __dirname;
const files = [
 ['批注40_总体技术路线图示方案.svg','批注40_总体技术路线图.png'],
 ['批注45_分层融合与更新图示方案.svg','批注45_分层融合与更新图.png'],
 ['飞机装配工序数据_前序结构图_283.svg','飞机装配工序数据_前序结构图_283.png'],
];
(async () => {
 for (const [source,target] of files) {
  const png = await sharp(fs.readFileSync(path.join(base,'deliverables',source)),{density:144})
    .flatten({background:'#fff'}).grayscale().png().toBuffer();
  fs.writeFileSync(path.join(base,'deliverables',target),png);
  const info=await sharp(png).metadata();
  console.log(JSON.stringify({file:target,width:info.width,height:info.height}));
 }
})().catch(err=>{console.error(err.message);process.exit(1)});
