"""One integrated data graph, and a consistent mixed-script font scheme.

Chinese: Droid Sans Fallback. Latin letters/digits: Nimbus Roman.
Actual font programs are subset-embedded. Accepted technical text and geometry
are preserved; no change is made to source process data or scheduling code.
"""
from pathlib import Path
from html import escape
import base64,csv,hashlib,io,json,re,shutil
import xml.etree.ElementTree as ET
import fitz
from fontTools import subset
from fontTools.ttLib import TTFont

B=Path(__file__).resolve().parent
S=B/'source/current/开题报告/00_总控与交付'
D=B/'deliverables';D.mkdir(exist_ok=True)
DATA=B/'source/grounding/283.csv'
with DATA.open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
byid={r['AO号']:r for r in rows}
groups={};current=None
for r in rows:
    if re.fullmatch(r'[A-Za-z]+-\d+',r['AO号']):
        current=r['AO号'];groups[current]=[]
    elif r['类型']=='2':groups[current].append(r['AO号'])
counts={g:len(v) for g,v in groups.items()}
assert counts=={'A-1':29,'A-2':132,'A-3':27,'A-4':34,'A-5':12,'A-6':49}
g_edges=[]
for g in groups:
    g_edges.extend((u.strip(),g) for u in re.split(r'[,，;；、]',byid[g]['紧前工序AO号']) if u.strip())
assert len(g_edges)==7
selected=['AJZYA4-0340','AJZYA5-0350','AJYYB2-0410']
assert set(selected)<=set(groups['A-3'])
local=[(u.strip(),v) for v in selected for u in re.split(r'[,，;；、]',byid[v]['紧前工序AO号']) if u.strip() in selected]
assert set(local)=={('AJZYA4-0340','AJZYA5-0350'),('AJZYA4-0340','AJYYB2-0410')}

parts=[]
def text(x,y,value,size=20,anchor='middle',weight=400):
    parts.append(f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{weight}" text-anchor="{anchor}" fill="#000">{escape(value)}</text>')
def line(points,arrow=False):
    marker=' marker-end="url(#arrow)"' if arrow else ''
    parts.append('<polyline points="'+' '.join(f'{x},{y}' for x,y in points)+'" fill="none" stroke="#000" stroke-width="1.6"'+marker+'/>')
def rect(x,y,w,h):parts.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="#fff" stroke="#000" stroke-width="1.4"/>')
def group(x,y,w,h,label,count):
    rect(x,y,w,h);text(x+w/2,y+26,label,21);text(x+w/2,y+52,f'{count}道工序',20)

text(34,37,'飞机装配工序数据的工艺前序结构（283道工序）',25,'start')
group(387,70,230,65,'A-1',counts['A-1'])
group(387,176,230,65,'A-2',counts['A-2'])
line([(502,135),(502,176)],True)
line([(502,241),(502,265),(323,265),(323,294)],True)
line([(502,265),(829,265),(829,294)],True)

# Three actual operations sit inside their own A-3 group; this is part of the
# same overview graph, not a second panel or a disconnected example.
rect(43,294,560,166)
text(323,322,'A-3：27道工序（节选3道）',20)
oppos={selected[0]:(223,336),selected[1]:(86,392),selected[2]:(361,392)}
for ao,(x,y) in oppos.items():
    rect(x,y,199,31);text(x+99.5,y+22,ao,18)
for u,v in local:
    x,y=oppos[u];xx,yy=oppos[v]
    line([(x+99.5,y+31),(x+99.5,380),(xx+99.5,380),(xx+99.5,yy)],True)
text(323,446,'其余工序及其依赖省略',17)

rect(699,294,260,166)
text(829,329,'A-4',21)
text(829,364,'34道工序',20)
text(829,411,'内部工序省略',17)
line([(323,460),(323,486),(502,486)])
line([(829,460),(829,486),(502,486)])
parts.append('<circle cx="502" cy="486" r="2.5" fill="#000"/>')
line([(502,486),(502,496)])
text(502,519,'两组全部工序均完成',19)
line([(502,528),(502,539),(323,539),(323,550)],True)
line([(502,539),(829,539),(829,550)],True)
group(208,550,230,65,'A-5',counts['A-5'])
group(714,550,230,65,'A-6',counts['A-6'])
text(34,648,'A-1等为数据分组编号，不对应物理站位；框内连线表示实际工序的前序关系。',18,'start')
text(34,678,'组间箭头要求前组全部完成；工艺上可并行的作业仍须满足人员等执行条件。',18,'start')

base='<svg xmlns="http://www.w3.org/2000/svg" width="1010" height="704" viewBox="0 0 1010 704" role="img"><title>283道工序数据的工艺前序结构</title><desc>单张总图中展示六组工序的依赖，并在A-3对应框内嵌入三道实际工序及其前序连线。中文与英文数字分别采用统一的字体。</desc><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto"><path d="M0 0L10 5L0 10Z" fill="#000"/></marker></defs><rect width="100%" height="100%" fill="#fff"/>'+''.join(parts)+'</svg>'
trees={'飞机装配工序数据_前序结构图_283.svg':ET.fromstring(base)}
for name in ['批注40_总体技术路线图示方案.svg','批注45_分层融合与更新图示方案.svg']:
    trees[name]=ET.fromstring((S/name).read_text())
all_text=''.join((e.text or '') for root in trees.values() for e in root.iter() if e.tag.split('}')[-1] in ['text','tspan'])
fontdir=B/'fonts';fontdir.mkdir(exist_ok=True)

def subset_font(font,chars,fname):
    worker=subset.Subsetter();worker.populate(text=chars);worker.subset(font)
    out=fontdir/fname;font.save(out)
    return base64.b64encode(out.read_bytes()).decode(),font.getBestCmap()
cjkfont=TTFont(io.BytesIO(fitz.Font('china-s').buffer))
cjk_chars=''.join(sorted({c for c in all_text if ord(c)>127}))
cjk_b64,cjk_cmap=subset_font(cjkfont,cjk_chars,'DroidSansFallback.ttf')
latin_chars=''.join(sorted({c for c in all_text if ord(c)<=127}))
roman_b64,roman_cmap=subset_font(TTFont('/usr/share/fonts/opentype/urw-base35/NimbusRoman-Regular.otf'),latin_chars,'NimbusRoman-Regular.otf')
bold_b64,bold_cmap=subset_font(TTFont('/usr/share/fonts/opentype/urw-base35/NimbusRoman-Bold.otf'),latin_chars,'NimbusRoman-Bold.otf')
assert all(ord(c) in cjk_cmap for c in cjk_chars)
assert all(ord(c) in roman_cmap and ord(c) in bold_cmap for c in latin_chars if not c.isspace())
css=f'''@font-face{{font-family:"Droid Sans Fallback";src:url(data:font/ttf;base64,{cjk_b64}) format("truetype");font-style:normal;font-weight:100 900;}}
@font-face{{font-family:"Nimbus Roman";src:url(data:font/otf;base64,{roman_b64}) format("opentype");font-weight:400;}}
@font-face{{font-family:"Nimbus Roman";src:url(data:font/otf;base64,{bold_b64}) format("opentype");font-weight:600 900;}}
text{{font-family:"Nimbus Roman","Droid Sans Fallback",serif;}}'''
ET.register_namespace('','http://www.w3.org/2000/svg')
for name,root in trees.items():
    oldstyles=[e for e in root if e.tag.split('}')[-1]=='style']
    for el in oldstyles:root.remove(el)
    style=ET.Element('{http://www.w3.org/2000/svg}style');style.text=css;root.insert(0,style)
    (D/name).write_text(ET.tostring(root,encoding='unicode'))
(B/'fontconfig.xml').write_text(f'<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig><dir>{fontdir}</dir><cachedir>{B}/fontcache</cachedir></fontconfig>')
manifest={'source':'283.csv','sha256':hashlib.sha256(DATA.read_bytes()).hexdigest(),
          'group_counts':counts,'group_edges':g_edges,'detail_group':'A-3',
          'detail_operations':selected,'detail_edges':local,'omitted_within_group':24,
          'layout':'one graph with operation detail inside its original group',
          'chinese_font':'Droid Sans Fallback','latin_font':'Nimbus Roman',
          'color_values':['#000','#fff'],'new_constraints':False}
(B/'figure_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
print(json.dumps(manifest,ensure_ascii=False))
